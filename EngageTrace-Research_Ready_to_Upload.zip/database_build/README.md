# Rebuilt EngageTrace SQLite database

This package rebuilds the supplied research database's courses, student-course memberships and weekly activity from the three OULAD CSVs. The database is intentionally excluded from this public package. Included are the original `engagetrace_db.py`, `schema.sql`, a safe rebuild runner, and a verification manifest. No raw OULAD CSVs or student-level exports are bundled.

## Use

First rebuild the database using the steps below. Then read the database with SQLite, DB Browser for SQLite, or Python:

```python
from engagetrace_db import EngageTraceDB

db = EngageTraceDB('engagetrace.db')
print(db.conn.execute('SELECT COUNT(*) FROM weekly_activity').fetchone()[0])
matrix = db.get_course_matrix('CCC_2014J')
# Optional export for the existing dashboard:
db.export_course_json('CCC_2014J', 'CCC_2014J_export.json')
db.close()
```

Exported JSON can be selected through **Load course data** in the redesigned dashboard. The dashboard does not connect directly to this SQLite file.

## Rebuild

1. Install Python 3.11 or later. The database builder uses only Python standard-library modules, including SQLite; no third-party packages are needed for this step.
2. Obtain the Open University Learning Analytics Dataset (OULAD) CSV archive through its official dataset site: https://analyse.kmi.open.ac.uk/open_dataset/
3. Extract `courses.csv`, `studentRegistration.csv`, and `studentVle.csv` into one local directory outside the repository. All three files are required; keep their original names.
4. Open a terminal in this repository's `database_build` folder. Replace the example paths below with your own paths. Choose a new output database path outside the repository.
5. Run:

```sh
python rebuild_database.py --input-dir /path/to/OULAD --database /path/to/new/engagetrace.db
```

6. Wait for the integrity and source-total checks to finish. The runner writes the database and a companion verification manifest. Inspect the manifest and terminal output before using the database. The archived `engagetrace.manifest.json` records the inputs and counts of the earlier verified build; SQLite file hashes may depend on the build environment.
7. Use the example above to query or export course activity. Run the paper's evaluations separately using the canonical research detector described in the root README.

The runner refuses to overwrite an existing database. Do not call the legacy `ingest_oulad` repeatedly on an existing database: its conflict handling adds click counts. Keep the database and raw CSVs outside GitHub. Upload only the source, schema, and documentation to this research repository.

## What is and is not reconstructed

The generated database uses the original research schema, including `courses`, `students`, `weekly_activity`, `detection_runs` and `detection_flags`. Detection tables are initialized but empty. No detector experiments or saved results were reconstructed, so this database need not match the size of the previously reported 506 MB file. A matching file size is not a verification criterion.

The original importer uses one-based weeks (`floor(date / 7) + 1`) and excludes pre-course events. It does not implement the requirements' enrollment eligibility and coverage/missing-data rules. `get_course_matrix` zero-fills missing weeks under the original behavior. Those policies must be reconciled before research validation. Student outcomes are not read from studentInfo.csv; the legacy final_result column remains empty.

US-01's versioned staging database remains a separate application artifact. This rebuild does not automatically migrate data to that schema or implement a local API.

## Provenance

Source: the OULAD archive supplied by Tolulope Oladipo. Dataset attribution: Jakub Kuzilek, Martin Hlosta and Zdenek Zdrahal, Open University Learning Analytics Dataset; CC BY 4.0. See `engagetrace.manifest.json` for exact input hashes, counts, database checksum and checks performed. The provided importer and schema are preserved unchanged.

## Dashboard export

Generate your own private course JSON using the example above and select it through Load course data in the dashboard. No student-level example export is included in the public repository. See Verification_Report.md for historical verification counts and limitations. This does not create a live database connection.
