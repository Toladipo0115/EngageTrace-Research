# EngageTrace v6 revision notes

The manuscript now integrates the completed post hoc mechanism analysis. It retains the IEEE template, author order, seven native equations, six existing figures and 32 references. The final PDF has 10 pages.

## Changes aligned with COSC722

- Abstract: Problem, gap, method, data and conditional result. Explicitly avoids a general superiority claim.
- Introduction: research questions and contributions now distinguish complete-method comparisons, the context-only ablation, exact stricter-cutoff comparison, suppression and timing.
- Methods: declares the post hoc plan and the secondary exact-cutoff audit after coarse outcomes were inspected. Describes how attainable no-context thresholds were identified.
- Results: new Section V-I and numerical Table IX replace the prior narrative synthesis table. The original numerical Tables IV-VIII remain unchanged. Existing raw-history and budget-transfer results remain visible.
- Discussion: explains where context differs from simply tightening a cutoff, and its costs in lost or delayed events. Prior rank interruptions are distinguished from current failures.
- Conclusion: states the observed deep-lull advantage and no-lull disadvantage together. Study 2 remains conditional on IRB approval and authorized access.

## Main new evidence

For the original seed, individual multiplier 0.25 and shared four-week lull multiplier 0.25, CAP detects 580/960 versus 527/960 for the best achievable stricter no-context cutoff at exactly 445/1,440 control flags. Within six weeks, counts are 513 versus 430 at 292 control flags. Without a lull, no-context detects 700 versus CAP 679 with fewer control flags (540 versus 559).

These are post hoc test-set oracle comparisons for the otherwise identical no-context rule, not prospective calibration or general superiority over raw history. The eleven seeds reuse the same eight presentations and are not independent replications. The exact audit is separately disclosed because coarse results were inspected first.

The companion mechanism package retains the full 28-condition outputs, all eleven seeds, source and data hashes, environment record, code, protocols and vector figures. Participant-level diagnostics are kept in a separate private package. The original default context ablation still loses 110 detections; a favorable tuned comparison does not erase that cost.

## Verification boundaries

The seven equation objects are byte-identical to v5. Original numerical Tables IV-VIII were checked unchanged; all new Table IX counts match the exact-frontier output. All 32 references are cited with first appearances in numerical order. The final rendered PDF was visually checked. This revision does not claim a fresh full-text audit of every source, native Microsoft Word testing, external validation, repository-history cleanup or completion of the separate clean-environment rebuild.
