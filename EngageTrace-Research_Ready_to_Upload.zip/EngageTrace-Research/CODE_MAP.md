# Paper v6 code map

| Paper material | Code and supporting files |
| --- | --- |
| CAP equations and canonical detectors | original-frozen-validation/code/engagetrace_detectors.py |
| Frozen sampling, injections, scoring | original-frozen-validation/code/run_validation.py and protocol.json |
| Poisson adaptation | original-frozen-validation/code/park_poisson.py |
| Original primary/scoring results | original-frozen-validation/results/ and analysis-scripts/experiments/ |
| Matched-rate curves, lulls, sensitivity and presentation tests | analysis-scripts/experiments/match.py, lull.py, run3.py, run4.py; saved JSON in analysis-scripts/results/ |
| Original exploratory grid and threshold calibration | extension-experiments/code/run_grid.py, summarize_grid.py, calibrate.py |
| Corrected withdrawal analysis | extension-experiments/code/withdrawal.py |
| New suppression diagnostics | engagetrace-mechanism/code/run_mechanism.py |
| Exact matched-control Table IX | engagetrace-mechanism/code/exact_frontier_audit.py and check_exact_canonical.py |
| New mechanism reports and vector figures | engagetrace-mechanism/code/summarize.py, interpret.py, report_exact.py |
| Original figure scripts | analysis-scripts/experiments/figs.py and figs2.py; extension-experiments/code/make_figures.py |
| Dashboard | dashboard/; demonstration interface, not a view of every research analysis |
| Database construction | database_build/rebuild_database.py, engagetrace_db.py, schema.sql |
| Current manuscript | paper/EngageTrace_ICICIP_Reviewed_v6.docx and .pdf |

The database importer retains the legacy detector; use the canonical research implementation for v6. New analysis results are files, not records inserted into the source database. Participant-level data and diagnostic files are excluded. The original development selection driver and tuning log remain unavailable. Historical analysis scripts may need path adaptation. The clean-environment rebuild remains outstanding; this repository is not certified as a complete one-command rebuild.
