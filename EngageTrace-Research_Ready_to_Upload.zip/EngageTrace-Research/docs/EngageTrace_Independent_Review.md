# Independent review of EngageTrace_ICICIP_Integrated (docx and pdf)

Renderer actually used: LibreOffice 24.2 Writer, headless, without its Math module, so it cannot draw Word equations. Microsoft Word was not available. The seven equations were checked as native OMML in the XML and against the specification, and the reviewed PDF shows them as typeset stand-in images. Equation appearance in Word is unverified.

## Verified correct (against saved scripts and results)
Tables IV to VIII, the sensitivity numbers in V-F, Table IX, the 28-condition detection and control ranges in V-H (-10.3 to +0.7, -18.4 to -3.6, -7.4 to +2.8, -14.1 to -1.4), both budget overruns (CAP 0.214 at budget 0.20, 0.317 at 0.30), the eligibility arithmetic (12,764 minus 2,008, 71, 2,638, 188, 217 leaves 7,642), the seven equations against the specification, and citation order (first appearance is 1 to 32, none uncited).

## Prioritized remaining issues
1. High. PDF p.9 left column: the ACKNOWLEDGMENT heading is stranded at the column bottom, its text at the top of the next column. Fixed in the reviewed file (keep with next).
2. High. PDF p.3: Algorithm 1 table is 10,454 twips wide inside a 5,047 twip column and ran past the right margin in the supplied PDF. Fixed (set to column width).
3. High. Repository claim (p.4, IV-E): github.com/Toladipo0115/COSC565-Software-Engineering- exists but lists no extension package, and it does list database and verification zips. Upload the extension public package, and review whether the database or student-ID files belong in a public repo.
4. High. Abstract and Conclusion said development-selected thresholds do not preserve budgets. Only CAP exceeded (0.214 and 0.317); the other families stayed under at attainable budgets, and CAP held the 0.10 budget (0.053). Reworded.
5. Medium. p.4 Table II last cell was unstyled and wrapped in the wrong font; its reference "Section V-H" omitted V-F and V-G where Fig. 5 and Table IX sit. Fixed.
6. Medium. Table IV was never cited in the running text. Added in V-A.
7. Medium. V-D: "CAP is lower than raw history in all eight (-11.7)" is a paired difference in lull-induced change at one multiplier (0.5), while V-H finds consistency only at multiplier 0.25. Reworded.
8. Medium. V-H gave the 28-condition cost range but not the detection cost where the benefit is consistent. Added (3.4 to 10.3 primary, 5.0 to 18.4 six-week).
9. Medium. IV-D described exact McNemar tests that are never reported. Removed.
10. Medium. IV-B called enrollment counts students (2,008 removed). Reworded to enrollments. Student-weeks are used consistently in Table IX; control flag rate is never called a false-positive rate.
11. Medium. Ten extra seeds draw from the same pools and share about one third (33.1 to 34.0 percent) of students with the original sample; stated.
12. Low to medium. Table X "external data planned" now states Study 2 depends on IRB approval and data-access authorization.
13. Low, not changed. Table III omits the ten extra seeds; the limitation sentence on seeds is in V-H only. Add a row if space allows.
14. Low, not changed. The Word equations are inline OMML with tabs, so eq. (4) may render with a compact fraction in Word. Check, or convert to display equations.
15. Low, not changed. Ref. [29] is cited only inside the range "[28] to [31]"; add an individual cite or drop it. IEEE usually writes ranges with a dash, which the no-dash rule avoids.
16. Page count is exactly 10 in this renderer (page 10 is half references). Word with Times New Roman may differ slightly; check before submission.
17. Not verifiable here: Al Doulat [23] (PDF never supplied); authors and affiliations.
