"""Check closed-form likelihood against direct Poisson likelihood and causal prefixes."""
import math,statistics
from park_poisson import fitted_part,detect_park_prefix
from engagetrace_detectors import detect_revised,REVISED_FINAL
x=[9,11,8,2,1,0];exposure=[4,7,3,9,6,5]
def direct(a,e):
 rate=sum(a)/sum(e)
 return sum(v*math.log(rate*b)-rate*b-math.lgamma(v+1) if v else -rate*b for v,b in zip(a,e))
constant=sum(v*math.log(e)-math.lgamma(v+1) for v,e in zip(x,exposure))
assert abs(direct(x,exposure)-(fitted_part(sum(x),sum(exposure))+constant))<1e-10
for split in range(1,len(x)):
 direct_gain=direct(x[:split],exposure[:split])+direct(x[split:],exposure[split:])-direct(x,exposure)
 closed_gain=fitted_part(sum(x[:split]),sum(exposure[:split]))+fitted_part(sum(x[split:]),sum(exposure[split:]))-fitted_part(sum(x),sum(exposure))
 assert abs(direct_gain-closed_gain)<1e-10
matrix={str(i):[100]*8+([1]*12 if i==0 else [100]*12) for i in range(12)}
f=detect_park_prefix(matrix);assert any(f['0'][8:]);assert not any(f['1'])
for end in range(2,21):
 short=detect_park_prefix({k:v[:end] for k,v in matrix.items()})
 assert all(short[k]==f[k][:end] for k in matrix)
for m in [{str(i):[0]*20 for i in range(4)},{str(i):[100]*6+[1]*14 for i in range(4)}]:assert not any(any(v) for v in detect_park_prefix(m).values())
# Fixed and CUSUM can alarm before revised CAP warm-up ends; score those weeks.
assert any(detect_revised({'a':[0]*20,'b':[0]*20},REVISED_FINAL)['a']['fixed'][:6])
print('PASS: direct likelihood, all candidate splits, isolated decline, prefix invariance, zero exposure, shared multiplier, early fixed alarms')
