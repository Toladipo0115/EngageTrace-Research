"""
EngageTrace detectors: one versioned module holding BOTH detector variants used
in the paper, plus the explicit post-onset scorer.

Why two detectors exist (see RUN_CONFIGS.md for provenance):

  detect_legacy   The first implementation (engagetrace_db.py, run_detection).
                  Raw-scale relative drop, immediate k-week baseline (no lag),
                  leave-one-out cohort MAD z-score, persistence p = 2.
                  Produced the six-course alert-volume table (Table I).

  detect_revised  The corrected implementation (controlled_eval.py,
                  compute_flags). log1p clicks, lagged baseline, cohort
                  percentile rank, persistence p = 3.
                  Produced the controlled-evaluation tables (II, III, ablation).

Both functions are pure: matrix in, flags out, no database access. The code
paths replicate the originals arithmetic-for-arithmetic; tests/ proves the
flags are identical to the originals. No configuration field has a default,
so a run can never silently pick up a stale setting.

Weeks are 1-based everywhere in outputs. Index i in a list is week i + 1.
"""

import bisect
import math
import statistics
from dataclasses import dataclass

DETECTOR_MODULE_VERSION = "2026.10.15-final"

LEGACY_METHODS = ("fixed", "individual", "cusum", "cap")
REVISED_METHODS = ("fixed", "individual", "cusum", "cap",
                   "cap_no_context", "cap_no_persistence", "cap_no_individual")


def _median(values):
    values = list(values)
    return statistics.median(values) if values else 0.0


def _mad(values):
    values = list(values)
    m = _median(values)
    return _median([abs(v - m) for v in values])


# ----------------------------------------------------------------------------
# Configurations (no defaults on purpose)
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class LegacyConfig:
    k: int                  # baseline window length, immediate previous k weeks (no lag)
    tau_ind: float          # raw relative-drop threshold, (base - x) / (base + 1e-6)
    tau_ctx: float          # leave-one-out cohort MAD z-score threshold
    p: int                  # consecutive weeks required
    fixed_threshold: float  # raw clicks below this for p weeks => fixed-rule flag


@dataclass(frozen=True)
class RevisedConfig:
    k: int                  # baseline window length (number of observations)
    lag: int                # weeks skipped between the baseline window and the candidate week
    tau_ind_raw: float      # raw relative-drop threshold used by the 'individual' baseline
    tau_ind_log: float      # log1p deviation threshold used by CAP and its ablations
    tau_ctx_pct: float      # cohort percentile-rank threshold (upper rank for ties)
    p: int                  # consecutive weeks required
    fixed_threshold: float  # raw clicks below this for p weeks => fixed-rule flag


# Settings behind the paper's tables, as recorded in the database run log
# (detection_runs: k=3, tau_individual=0.5, tau_context=1.5, persistence_p=2) and
# in controlled_eval_category_breakdown.json (k=3, LAG=3, tau_ind_log=0.2,
# tau_ctx_percentile=0.6, persistence_p=3, fixed_threshold=6).
LEGACY_TABLE1 = dict(k=3, tau_ind=0.5, tau_ctx=1.5, p=2)          # + per-course fixed_threshold
REVISED_FINAL = RevisedConfig(k=3, lag=3, tau_ind_raw=0.5, tau_ind_log=0.2,
                              tau_ctx_pct=0.6, p=3, fixed_threshold=6.0)


# ----------------------------------------------------------------------------
# Legacy detector (raw scale, cohort MAD, no lag, p = 2 in Table I)
# ----------------------------------------------------------------------------

def detect_legacy(matrix, cfg: LegacyConfig):
    """matrix: {student_id: [clicks_week1, ...]} -> {student_id: {method: [bool per week]}}."""
    k, p = cfg.k, cfg.p
    student_ids = list(matrix.keys())
    weeks = len(next(iter(matrix.values())))

    deltas = {sid: [None] * weeks for sid in student_ids}
    for sid in student_ids:
        vals = matrix[sid]
        for i in range(weeks):
            if i + 1 <= k:
                continue
            base = _median(vals[i - k:i])
            deltas[sid][i] = (base - vals[i]) / (base + 1e-6)

    z_scores = {sid: [None] * weeks for sid in student_ids}
    for i in range(weeks):
        week_deltas = {sid: deltas[sid][i] for sid in student_ids if deltas[sid][i] is not None}
        for sid in week_deltas:
            others = [v for s, v in week_deltas.items() if s != sid]
            if not others:
                continue
            med = _median(others)
            madv = _mad(others)
            z_scores[sid][i] = (week_deltas[sid] - med) / (madv + 1e-6)

    flags = {sid: {m: [False] * weeks for m in LEGACY_METHODS} for sid in student_ids}
    for sid in student_ids:
        vals = matrix[sid]
        fixed_run = ind_run = cap_run = 0
        mu0 = _median(vals[:min(k, weeks)])
        slack = 0.25 * mu0
        H = 2 * mu0
        S = 0.0
        for i in range(weeks):
            fixed_run = fixed_run + 1 if vals[i] < cfg.fixed_threshold else 0
            flags[sid]["fixed"][i] = fixed_run >= p

            d = deltas[sid][i]
            ind_run = ind_run + 1 if (d is not None and d >= cfg.tau_ind) else 0
            flags[sid]["individual"][i] = ind_run >= p

            S = max(0.0, S + (mu0 - vals[i]) - slack)
            flags[sid]["cusum"][i] = bool(S > H and mu0 > 0)

            z = z_scores[sid][i]
            cond = d is not None and z is not None and d >= cfg.tau_ind and z >= cfg.tau_ctx
            cap_run = cap_run + 1 if cond else 0
            flags[sid]["cap"][i] = cap_run >= p
    return flags


# ----------------------------------------------------------------------------
# Revised detector (log1p, lagged baseline, cohort percentile rank, p = 3)
# ----------------------------------------------------------------------------

def detect_revised(matrix, cfg: RevisedConfig):
    """Same contract as detect_legacy, plus the three CAP ablation variants.

    Percentile rank is count(x <= v) / n over the cohort of eligible deviations that
    week, focal student included, so ties receive the UPPER rank (an all-tied
    cohort gets rank 1.0). bisect_right on the sorted list gives that count exactly.
    """
    k, lag, p = cfg.k, cfg.lag, cfg.p
    student_ids = list(matrix.keys())
    weeks = len(next(iter(matrix.values())))

    log_matrix = {sid: [math.log1p(v) for v in matrix[sid]] for sid in student_ids}

    deltas = {sid: [None] * weeks for sid in student_ids}       # raw scale ('individual' baseline)
    log_deltas = {sid: [None] * weeks for sid in student_ids}   # log scale (CAP and ablations)
    for sid in student_ids:
        vals = matrix[sid]
        lvals = log_matrix[sid]
        for i in range(weeks):
            if i + 1 <= k + lag:
                continue
            base = _median(vals[i - k - lag:i - lag])
            deltas[sid][i] = (base - vals[i]) / (base + 1e-6)
            lbase = _median(lvals[i - k - lag:i - lag])
            log_deltas[sid][i] = lbase - lvals[i]

    percentiles = {sid: [None] * weeks for sid in student_ids}
    for i in range(weeks):
        week_ld = {sid: log_deltas[sid][i] for sid in student_ids if log_deltas[sid][i] is not None}
        if len(week_ld) < 2:
            continue
        sorted_vals = sorted(week_ld.values())
        n = len(sorted_vals)
        for sid, v in week_ld.items():
            percentiles[sid][i] = bisect.bisect_right(sorted_vals, v) / n

    flags = {sid: {m: [False] * weeks for m in REVISED_METHODS} for sid in student_ids}
    for sid in student_ids:
        vals = matrix[sid]
        fixed_run = ind_run = cap_run = ctx_run = indiv_run = 0
        mu0 = _median(vals[:min(k, weeks)])
        slack = 0.25 * mu0
        H = 2 * mu0
        S = 0.0
        for i in range(weeks):
            fixed_run = fixed_run + 1 if vals[i] < cfg.fixed_threshold else 0
            flags[sid]["fixed"][i] = fixed_run >= p

            d = deltas[sid][i]
            ind_run = ind_run + 1 if (d is not None and d >= cfg.tau_ind_raw) else 0
            flags[sid]["individual"][i] = ind_run >= p

            S = max(0.0, S + (mu0 - vals[i]) - slack)
            flags[sid]["cusum"][i] = bool(S > H and mu0 > 0)

            z = percentiles[sid][i]
            ld = log_deltas[sid][i]

            cond_full = ld is not None and z is not None and ld >= cfg.tau_ind_log and z >= cfg.tau_ctx_pct
            cap_run = cap_run + 1 if cond_full else 0
            flags[sid]["cap"][i] = cap_run >= p

            cond_no_ctx = ld is not None and ld >= cfg.tau_ind_log
            ctx_run = ctx_run + 1 if cond_no_ctx else 0
            flags[sid]["cap_no_context"][i] = ctx_run >= p

            flags[sid]["cap_no_persistence"][i] = cond_full

            cond_no_ind = z is not None and z >= cfg.tau_ctx_pct
            indiv_run = indiv_run + 1 if cond_no_ind else 0
            flags[sid]["cap_no_individual"][i] = indiv_run >= p
    return flags


# ----------------------------------------------------------------------------
# Scoring
# ----------------------------------------------------------------------------

N_WEEKS = 20

POSITIVE_SCENARIOS = {"individual_sustained_decline", "decline_during_quiet"}

# First week at which the scenario's injected event can matter. Flags at weeks
# BEFORE this are pre-onset alarms and never count as detections. The two
# positive onsets are the injection weeks in controlled_eval.py. The negative
# scenarios use the onset of the event they are the control for (a convention,
# stated so the windows are explicit): no_change is scored over the same weeks
# as sustained decline, the temporary dip over week 15 onward, and quiet-only
# from the start of the shared quiet period.
SCENARIO_ONSET = {
    "no_change": 12,
    "individual_sustained_decline": 12,
    "temporary_dip_recovered": 15,
    "course_wide_quiet_only": 7,
    "decline_during_quiet": 7,
}
SCENARIO_ORDER = ["no_change", "course_wide_quiet_only", "individual_sustained_decline",
                  "temporary_dip_recovered", "decline_during_quiet"]

# Original any-time scorer's onset table (positives only), kept for reproduction.
_LEGACY_TRUE_ONSET = {"individual_sustained_decline": 12, "decline_during_quiet": 7}


def _window(onset, window, n_weeks):
    """Inclusive (first_week, last_week) of the scoring window."""
    if window == "to_end":
        return onset, n_weeks
    if window == "w6":
        return onset, min(n_weeks, onset + 5)
    raise ValueError(window)


def _rate(a, b):
    return (a / b) if b else None


def score_post_onset(flags, assignment, methods, window="to_end", n_weeks=N_WEEKS):
    """Explicit post-onset scoring.

    For every sequence the scoring window is [onset, end] for its scenario.
      positive scenario: detected   = at least one flag inside the window
                         delay      = first in-window flag week - onset
      negative scenario: flagged    = at least one flag inside the window
    Flags before the onset are NEVER counted as detections. They are tallied
    separately per sequence as pre_onset_alarm. strict_* additionally requires
    that the sequence had no pre-onset alarm (alert state begins after onset).

    Returns {method: {...counts and rates...}} plus per-scenario fractions.
    """
    out = {}
    for m in methods:
        pos = dict(n=0, detected=0, strict_detected=0, pre_alarm=0, delays=[])
        neg = dict(n=0, flagged=0, strict_flagged=0, pre_alarm=0)
        per = {s: dict(n=0, flagged=0, pre_alarm=0) for s in SCENARIO_ORDER}
        for sid, scen in assignment.items():
            onset = SCENARIO_ONSET[scen]
            lo, hi = _window(onset, window, n_weeks)
            weeks_flagged = [i + 1 for i, f in enumerate(flags[sid][m]) if f]
            inwin = [w for w in weeks_flagged if lo <= w <= hi]
            pre = any(w < onset for w in weeks_flagged)
            per[scen]["n"] += 1
            per[scen]["flagged"] += bool(inwin)
            per[scen]["pre_alarm"] += pre
            if scen in POSITIVE_SCENARIOS:
                pos["n"] += 1
                pos["pre_alarm"] += pre
                if inwin:
                    pos["detected"] += 1
                    pos["strict_detected"] += (not pre)
                    pos["delays"].append(inwin[0] - onset)
            else:
                neg["n"] += 1
                neg["pre_alarm"] += pre
                if inwin:
                    neg["flagged"] += 1
                    neg["strict_flagged"] += (not pre)
        out[m] = {
            "window": window,
            "n_positive": pos["n"], "n_negative": neg["n"],
            "detected_post_onset": pos["detected"],
            "detection_rate": _rate(pos["detected"], pos["n"]),
            "strict_detection_rate": _rate(pos["strict_detected"], pos["n"]),
            "pre_onset_alarm_rate_positive": _rate(pos["pre_alarm"], pos["n"]),
            "mean_delay_weeks": (sum(pos["delays"]) / len(pos["delays"])) if pos["delays"] else None,
            "negative_flagged_post_onset": neg["flagged"],
            "negative_flag_rate": _rate(neg["flagged"], neg["n"]),
            "strict_negative_flag_rate": _rate(neg["strict_flagged"], neg["n"]),
            "pre_onset_alarm_rate_negative": _rate(neg["pre_alarm"], neg["n"]),
            "per_scenario": {s: {"n": v["n"], "flagged": v["flagged"],
                                 "fraction": v["flagged"] / v["n"] if v["n"] else None,
                                 "pre_onset_alarm_fraction": v["pre_alarm"] / v["n"] if v["n"] else None}
                             for s, v in per.items()},
        }
    return out


def score_any_time_original(flags, assignment, methods):
    """The ORIGINAL scorer, reproduced only to show the earlier tables are reproducible.

    A sequence counts as flagged if any flag occurs anywhere in the 20 weeks, so a
    pre-onset flag is credited as a detection (delay = max(0, first - onset)).
    Not suitable as evidence of event-specific detection.
    """
    out = {}
    for m in methods:
        tp = fn = fp = tn = 0
        delays, locs = [], []
        for sid, scen in assignment.items():
            weeks_flagged = [i + 1 for i, f in enumerate(flags[sid][m]) if f]
            if scen in POSITIVE_SCENARIOS:
                if weeks_flagged:
                    tp += 1
                    onset = _LEGACY_TRUE_ONSET[scen]
                    delays.append(max(0, weeks_flagged[0] - onset))
                    locs.append(abs(weeks_flagged[0] - onset))
                else:
                    fn += 1
            else:
                if weeks_flagged:
                    fp += 1
                else:
                    tn += 1
        out[m] = {
            "detection_rate": round(tp / (tp + fn), 3),
            "false_positive_rate": round(fp / (fp + tn), 3),
            "mean_delay_weeks": round(statistics.mean(delays), 2) if delays else None,
            "mean_localization_error_weeks": round(statistics.mean(locs), 2) if locs else None,
            "tp": tp, "fn": fn, "fp": fp, "tn": tn,
        }
    return out


def wilson_interval(successes, n, z=1.96):
    """95% Wilson score interval for a binomial proportion."""
    if n == 0:
        return (None, None)
    ph = successes / n
    denom = 1 + z * z / n
    centre = (ph + z * z / (2 * n)) / denom
    half = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))
