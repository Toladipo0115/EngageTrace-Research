"""Frozen validation on previously unevaluated presentations; full pre-onset scoring.
Run from package root: python code/run_transfer.py --database PATH --registration PATH
The specified data are public OULAD inputs; no detector parameters are tuned here.
"""
import argparse,csv,json,hashlib,platform,random,sqlite3,statistics,time
from pathlib import Path
from collections import defaultdict
from engagetrace_detectors import RevisedConfig,detect_revised,REVISED_METHODS
from park_poisson import detect_park_prefix
BASE=Path(__file__).resolve().parent.parent
SCENARIOS=['no_change','sustained','temporary','quiet_only','decline_during_quiet']
ONSETS=dict(zip(SCENARIOS,[12,12,15,7,7]));POS={'sustained','decline_during_quiet'}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def writecsv(path,rows):
 with Path(path).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def load_data(db,reg,cfg):
 registrations=list(csv.DictReader(Path(reg).open()));dev={r['id_student'] for r in registrations if r['code_module']+'_'+r['code_presentation'] in cfg['development_presentations']}
 counts=defaultdict(int);eligible=defaultdict(list)
 for r in registrations:
  if r['code_module']+'_'+r['code_presentation'] not in cfg['evaluation_presentations']:continue
  counts['candidate_enrollments']+=1
  if r['id_student'] in dev:counts['shared_student_purged']+=1;continue
  if r['date_registration'] in ('','?') or int(r['date_registration'])>0:counts['late_or_unknown_registration']+=1;continue
  if r['date_unregistration'] not in ('','?') and int(r['date_unregistration'])<140:counts['unregistered_before_window_end']+=1;continue
  eligible[r['code_module']+'_'+r['code_presentation']].append(r['id_student'])
 data={}
 with sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True) as con:
  for course,ids in sorted(eligible.items()):
   matrix={sid:[0]*20 for sid in ids}
   for sid,w,x in con.execute('SELECT student_id,week,clicks FROM weekly_activity WHERE course_id=? AND week BETWEEN 1 AND 20',(course,)):
    if sid in matrix:matrix[sid][w-1]=x
   for sid in list(matrix):
    if not sum(matrix[sid]):counts['zero_total_clicks']+=1;del matrix[sid]
   data[course]=matrix
 counts['eligible_before_cross_course_deduplication']=sum(map(len,data.values()))
 seen=set()
 for course,pool in sorted(data.items()):
  for sid in list(pool):
   if sid in seen:counts['duplicate_evaluation_enrollment_purged']+=1;del pool[sid]
   else:seen.add(sid)
 counts['eligible_enrollments']=sum(map(len,data.values()))
 assert set(data)==set(cfg['evaluation_presentations'])
 assert not seen.intersection(dev)
 assert len(seen)==counts['eligible_enrollments']
 assert all(len(pool)>=300 for pool in data.values())
 return data,dict(counts)
def flags(matrix,cfg):
 result=detect_revised(matrix,RevisedConfig(**cfg));park=detect_park_prefix(matrix)
 for sid in result:result[sid]['park_prefix_poisson']=park[sid]
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--database',required=True);ap.add_argument('--registration',required=True);a=ap.parse_args()
 cfg=json.loads((BASE/'protocol.json').read_text());assert sha(BASE/'protocol.json')==(BASE/'protocol.sha256').read_text().split()[0], 'Frozen protocol hash changed'
 out=BASE/'results';out.mkdir(exist_ok=True)
 # Provenance is written before computing any new outcomes.
 provenance=dict(protocol_sha256=sha(BASE/'protocol.json'),source_hashes={str(Path(p).name):sha(p) for p in [a.database,a.registration,__file__,Path(__file__).with_name('engagetrace_detectors.py'),Path(__file__).with_name('park_poisson.py')]},python=platform.python_version(),status='started')
 (out/'run_manifest.json').write_text(json.dumps(provenance,indent=2))
 data,counts=load_data(a.database,a.registration,cfg);rows=[];assign=[];starttime=time.monotonic()
 print('Eligibility',counts,flush=True)
 for course,pool in sorted(data.items()):
  for seed in cfg['seeds']:
   ids=random.Random(f'{course}:{seed}').sample(sorted(pool),300)
   original={sid:pool[sid][:] for sid in ids};base=flags(original,cfg['detector'])
   for q in cfg['quiet_lengths']:
    injected={};cat={}
    for j,sid in enumerate(ids):
     category=SCENARIOS[j//60];cat[sid]=category;v=pool[sid][:]
     for w in range(7,7+q):v[w-1]=round(v[w-1]*.5)
     if category in POS:
      for w in range(ONSETS[category],21):v[w-1]=round(v[w-1]*.25)
     elif category=='temporary':v[14]=round(v[14]*.25)
     injected[sid]=v
     assign.append(dict(course=course,seed=seed,student=sid,scenario=category,quiet_length=q))
    got=flags(injected,cfg['detector'])
    for sid in ids:
     scenario=cat[sid];begin=ONSETS[scenario]-1
     for method,seq in got[sid].items():
      earlier=any(seq[:begin]) # ALL preceding weeks, including fixed/CUSUM warm-up.
      for window,end in [('to_end',20),('six_week',min(begin+6,20))]:
       hits=[t for t in range(begin,end) if seq[t]];alarm=bool(hits)
       rows.append(dict(course=course,seed=seed,student=sid,scenario=scenario,quiet_length=q,window=window,method=method,positive=int(scenario in POS),alarm=int(alarm),pre_onset_alarm=int(earlier),strict_alarm=int(alarm and not earlier),baseline_alarm=int(any(base[sid][method][begin:end])),new_episode=int(any(seq[t] and (t==0 or not seq[t-1]) for t in range(begin,end))),delay=hits[0]-begin if hits else ''))
  print('Completed',course,flush=True)
 writecsv(out/'case_results.csv',rows);writecsv(out/'assignments.csv',assign)
 groups=defaultdict(list)
 for r in rows:groups[(r['quiet_length'],r['window'],r['course'],r['seed'],r['method'],r['scenario'])].append(r)
 summaries=[]
 for (q,w,c,s,m,g),rr in sorted(groups.items()):
  item=dict(quiet_length=q,window=w,course=c,seed=s,method=m,scenario=g,n=len(rr))
  for key in ['alarm','pre_onset_alarm','strict_alarm','baseline_alarm','new_episode']:item[key+'_rate']=statistics.mean(r[key] for r in rr)
  delays=[r['delay'] for r in rr if r['delay']!=''];item['mean_delay']=statistics.mean(delays) if delays else '';summaries.append(item)
 writecsv(out/'course_seed_results.csv',summaries)
 overall=[]
 for q in cfg['quiet_lengths']:
  for w in ['to_end','six_week']:
   for m in [*REVISED_METHODS,'park_prefix_poisson']:
    for role,pos in [('positive',True),('negative',False)]:
     selected=[r for r in summaries if r['quiet_length']==q and r['window']==w and r['method']==m and (r['scenario'] in POS)==pos];course=defaultdict(list)
     for r in selected:course[r['course']].append(r)
     entry=dict(quiet_length=q,window=w,method=m,group=role,courses=len(course))
     for metric in ['alarm_rate','pre_onset_alarm_rate','strict_alarm_rate','baseline_alarm_rate','new_episode_rate']:
      means=[statistics.mean(r[metric] for r in group) for group in course.values()];entry[metric]=statistics.mean(means)
      if metric=='alarm_rate':
       rng=random.Random(1026);samples=sorted(statistics.mean(rng.choices(means,k=len(means))) for _ in range(10000));entry['descriptive95_low']=samples[250];entry['descriptive95_high']=samples[9749]
     overall.append(entry)
 writecsv(out/'summary.csv',overall)
 provenance.update(status='completed',counts=counts,course_pool_sizes={c:len(v) for c,v in data.items()},unique_evaluation_students=len({sid for pool in data.values() for sid in pool}),case_rows=len(rows),elapsed_seconds=round(time.monotonic()-starttime,2))
 (out/'run_manifest.json').write_text(json.dumps(provenance,indent=2));print('Saved',len(rows),'case rows',flush=True)
if __name__=='__main__':main()
