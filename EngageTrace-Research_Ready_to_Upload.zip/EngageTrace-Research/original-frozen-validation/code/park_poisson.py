"""Weekly prefix adaptation of Park et al. (2017), Eqs. 6,9,11,12.
This is an independent implementation of the Poisson branch, NOT authors' code.
Differences: refit every weekly prefix; expose downward changes only; split means
first post-change index; allow 1 observation in either segment; no run requirement.
Background is cohort mean including focal student. BIC parameters are 1 vs 3.
All-zero weeks have zero exposure/count; likelihood handled by its zero limit.
"""
import math

def fitted_part(total,exposure):
    if total==0:return 0.0
    if exposure<=0:raise ValueError('Positive count with zero cohort exposure')
    return total*math.log(total/exposure)-total

def detect_park_prefix(matrix):
    ids=list(matrix);n=len(ids);T=len(matrix[ids[0]])
    means=[sum(matrix[s][t] for s in ids)/n for t in range(T)]
    exposures=[0.0]
    for v in means:exposures.append(exposures[-1]+v)
    output={s:[False]*T for s in ids}
    for sid in ids:
        sums=[0]
        for v in matrix[sid]:sums.append(sums[-1]+v)
        for t in range(2,T+1):
            total=sums[t];E=exposures[t]
            if not total or not E:continue
            null=fitted_part(total,E);best=-math.inf;rates=None
            for split in range(1,t):
                a=sums[split];b=total-a;ea=exposures[split];eb=E-ea
                ll=fitted_part(a,ea)+fitted_part(b,eb)
                if ll>best:
                    best=ll;rates=(a/ea if ea else 0.0,b/eb if eb else 0.0)
            output[sid][t-1]=(2*(best-null)>2*math.log(t) and rates[1]<rates[0])
    return output
