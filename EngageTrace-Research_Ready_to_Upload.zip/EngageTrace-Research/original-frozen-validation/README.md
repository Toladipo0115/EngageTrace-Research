# EngageTrace frozen validation on previously unevaluated presentations

Read Validation_Report.md and the immutable protocol.json before using the results. Its SHA-256 checksum was recorded before this run. All eight declared presentations and methods are included. The test samples 2,400 distinct students without overlap with fourteen earlier presentations or across test courses. It is retrospective transfer within familiar OULAD modules, not an external or globally untouched dataset.

## Reproduce

Python 3.12, standard library only. Supply the rebuilt OULAD SQLite database and original studentRegistration.csv. The database is intentionally not bundled.

```bash
python code/test_park.py
python code/run_validation.py --database /path/engagetrace.db --registration /path/studentRegistration.csv
python code/audit_and_report.py /path/studentRegistration.csv
```

Run from the extracted package. Scripts write to results and the report; copy the package first if preserving the delivered outputs. protocol.json must match protocol.sha256; do not edit the frozen protocol to accommodate unfavorable results. The report includes both primary start-to-week20 and sensitivity six-week outcomes. results/summary.csv includes all methods, both lull lengths, all earlier alarms, strict detection, new episodes, and descriptive intervals. The supplementary paired differences are descriptive, not a registered superiority test.

Original sources and earlier result packages remain unchanged. This package contains no raw OULAD database. Sampling assignments are preserved using the public dataset identifiers.
