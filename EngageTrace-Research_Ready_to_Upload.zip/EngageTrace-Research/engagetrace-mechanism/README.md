# EngageTrace post hoc mechanism analysis

New analysis of the existing samples, not independent confirmation. Read Mechanism_Analysis_Report.md and the hashed mechanism_protocol.json. Original files remain unchanged.

Public package contains source, aggregate outputs, vector figures, exact installed dependency versions and input hashes. Private diagnostic NPZ files contain identifiers and are not distributed here. Their schema includes IDs, scenarios, log decline, cohort rank, individual condition, CAP/no-context flags and current/earlier-rank suppression. Those files are generated locally by the script.

Inputs: original extension package (code and vendor folders), OULAD-derived database, studentRegistration.csv, and the original frozen assignments.csv. Paths are explicit command arguments; no private paths are embedded. The original assignments are checked against the documented sampler for all eight presentations. No historical development sampler is reconstructed.

Use Python version recorded in mechanism_data_manifest.json and install requirements-lock.txt in your own isolated environment. The archived execution used the existing environment; installing those requirements later is not itself proof of a clean rebuild.

Execute run_mechanism.py, then summarize.py as documented in the report. All conditions and seeds must finish before interpreting outputs. Regeneration compares canonical flags and saved integer grid counts. Public result CSVs contain only presentation-level or aggregate values, with no student IDs.
