from pathlib import Path
import csv,json,collections,statistics,hashlib,gzip
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]
def read(n):
 out=[]
 path=R/'results'/n
 stream=path.open() if path.exists() else gzip.open(str(path)+'.gz','rt')
 for row in csv.DictReader(stream):
  for k,v in row.items():
   if v=='':row[k]=None
   else:
    try:row[k]=float(v)
    except ValueError:pass
  out.append(row)
 return out
def write(n,rows):
 with (R/'results'/n).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def mean(x):return statistics.mean(x)
def desc(x):return f'{mean(x):.3f}'
rows=read('mechanism_presentation_table.csv');sw=read('threshold_sweep_presentation.csv');fact=read('factorial_presentation_table.csv')
groups=collections.defaultdict(list)
for r in sw:groups[tuple(r[k] for k in ['seed','d','q','s','window','method','threshold'])].append(r)
points=collections.defaultdict(list)
for (seed,d,q,s,window,method,threshold),rr in groups.items():
 assert len(rr)==8
 points[(seed,d,q,s,window,method)].append(dict(threshold=threshold,control=mean([r['ctrl']/r['nctrl'] for r in rr]),detection=mean([r['pos']/r['npos'] for r in rr]),strict=mean([r['strict']/r['npos'] for r in rr]),pre=mean([r['pos_pre']/r['npos'] for r in rr])))
a2=[]
for key,pp in points.items():
 if key[-1]!='cap':continue
 cap=next(p for p in pp if p['threshold']==.2);nc=points[key[:-1]+('no_context',)];budget=cap['control']
 feasible=[p for p in nc if p['control']<=budget+1e-12];best=max(feasible,key=lambda p:(p['detection'],p['control'])) if feasible else None
 above=[p for p in nc if p['control']>budget+1e-12];high=min(above,key=lambda p:(p['control'],-p['detection'])) if above else None
 interp=None
 if best and abs(best['control']-budget)<1e-12:interp=best['detection']
 elif best and high:interp=best['detection']+(high['detection']-best['detection'])*(budget-best['control'])/(high['control']-best['control'])
 seed,d,q,s,window,_=key
 a2.append(dict(seed=seed,d=d,q=q,s=s,window=window,cap_control=budget,cap_detection=cap['detection'],nc_feasible_threshold=best['threshold'] if best else None,nc_feasible_control=best['control'] if best else None,nc_feasible_detection=best['detection'] if best else None,cap_minus_nc_feasible=cap['detection']-best['detection'] if best else None,nc_above_threshold=high['threshold'] if high else None,nc_above_control=high['control'] if high else None,nc_above_detection=high['detection'] if high else None,nc_interpolated_detection=interp,cap_minus_nc_interpolated=cap['detection']-interp if interp is not None else None))
write('A2_matched_control_comparison.csv',a2)
# Condition table: equal presentation means; ratios computed within each presentation.
agg=[]
g=collections.defaultdict(list)
for r in rows:g[tuple(r[k] for k in ['seed','d','q','s','window','group'])].append(r)
for key,rr in g.items():
 seed,d,q,s,w,group=key
 out=dict(seed=seed,d=d,q=q,s=s,window=w,group=group)
 for k in ['suppressed_per100','suppression_fraction','nc_flagged_weeks','suppressed_weeks','current_rank','prior_rank','prior_lull_only','prior_outside_only','prior_mixed']:
  vals=[r[k] for r in rr if r[k] is not None];out[k]=mean(vals) if vals else None
 for method in ['nc','cap']:
  for metric in ['detected','pre','strict']:out[f'{method}_{metric}_rate']=mean([r[f'{method}_{metric}']/r['n'] for r in rr])
 for metric in ['same_first','later_first','lost','neither']:
  out[metric+'_all_positive_rate']=mean([r[metric]/r['n'] for r in rr]) if group=='positive' else None
  denom=[r[metric]/r['nc_detected'] for r in rr if r['nc_detected']>0] if group=='positive' else []
  out[metric+'_nc_detected_fraction']=mean(denom) if denom and metric!='neither' else None
 out['pooled_n']=int(sum(r['n'] for r in rr));out['pooled_nc_detected']=int(sum(r['nc_detected'] for r in rr));out['pooled_cap_detected']=int(sum(r['cap_detected'] for r in rr));out['pooled_lost']=int(sum(r['lost'] for r in rr)) if group=='positive' else None
 agg.append(out)
write('mechanism_aggregate_table.csv',agg)
selected=[(0,None),(2,.5),(4,.25)];labels=['No lull','2 weeks × 0.50','4 weeks × 0.25']
fig,axes=plt.subplots(1,3,figsize=(13.5,4.2))
colors=['#006c70','#da8c22','#7c4c97']
for color,(q,s),label in zip(colors,selected,labels):
 for method,ls in [('cap','-'),('no_context','--')]:
  ps=points[(20261015,.25,q,s,'to_end',method)];ps=sorted(ps,key=lambda x:x['control']);axes[0].plot([p['control'] for p in ps],[p['detection'] for p in ps],ls,color=color,lw=1.2,marker='.',markersize=2,label=label+(' CAP' if method=='cap' else ' NC'))
axes[0].set(xlabel='Control students flagged',ylabel='Injected events detected',title='A. Achievable threshold points',xlim=(0,.8),ylim=(0,1));axes[0].legend(fontsize=6,loc='lower right')
# Current vs prior interruption; equal presentation mean per100 eligible weeks.
x=np.arange(6);bottom=np.zeros(6)
for field,color,label in [('current_rank','#167e9b','Current-week rank failure'),('prior_rank','#dd9c3c','Earlier rank interruption')]:
 vals=[]
 for q,s in selected:
  for group in ['control','positive']:
   rr=g[(20261015,.25,q,s,'to_end',group)];vals.append(mean([100*r[field]/r['eligible_weeks'] for r in rr]))
 axes[1].bar(x,vals,bottom=bottom,color=color,label=label);bottom+=vals
axes[1].set_xticks(x,['C\nNo lull','P\nNo lull','C\n2w .50','P\n2w .50','C\n4w .25','P\n4w .25'],fontsize=7);axes[1].set(ylabel='Suppressed flags / 100 eligible weeks',title='B. How weekly flags disappear');axes[1].legend(fontsize=7)
bottom=np.zeros(3)
for field,color,label in [('same_first','#287f79','Same first post-onset week'),('later_first','#e0a13a','Later first post-onset week'),('lost','#b45d69','Undetected by CAP')]:
 vals=[]
 for q,s in selected:
  rr=g[(20261015,.25,q,s,'to_end','positive')];vals.append(mean([r[field]/r['nc_detected'] for r in rr]))
 axes[2].bar(np.arange(3),vals,bottom=bottom,color=color,label=label);bottom+=vals
axes[2].set_xticks(np.arange(3),['No lull','2w × .50','4w × .25'],fontsize=8);axes[2].set(ylabel='Fraction of NC-detected events',title='C. Consequence for event detection',ylim=(0,1));axes[2].legend(fontsize=7,loc='lower left')
for ax in axes:ax.spines[['top','right']].set_visible(False)
fig.tight_layout()
for ext in ['pdf','svg','png']:fig.savefig(R/'figures'/f'Mechanism_Analysis.{ext}',dpi=300,bbox_inches='tight')
lines=['# EngageTrace: post hoc mechanism analysis','', 'This analysis was specified after all existing evaluations had been examined. It is explanatory, not independent confirmation. No original detector, sample, threshold default, or result was edited.','', '## A2: context versus a stricter individual cutoff','', 'Both rules use the same log-decline features, lag and persistence. Rank is fixed at 0.6 for CAP; the individual cutoff is swept over the archived plan’s grid. The table uses default CAP as the control-rate target. The no-context feasible point is the best tested detection at or below that rate. Interpolation is a test-set descriptive construction, not a deployable setting or development-selected threshold.','', '| Condition, d=0.25 | Window | CAP control | CAP detection | NC feasible control / detection | NC interpolated detection |','|---|---|---:|---:|---:|---:|']
for q,s in selected:
 for window in ['to_end','six_week']:
  r=next(r for r in a2 if r['seed']==20261015 and r['d']==.25 and r['q']==q and r['s']==s and r['window']==window)
  lines.append(f"| q={q}, multiplier={s} | {window} | {r['cap_control']:.3f} | {r['cap_detection']:.3f} | {r['nc_feasible_control']:.3f} / {r['nc_feasible_detection']:.3f} | {r['nc_interpolated_detection']:.3f} |")
lines+=['','## A3: flags, events and timing','','Weekly suppression is partitioned into current rank failure and interruption earlier in the three-week run. Categories account for all suppressed flags. A failed rank in a lull is an observed interruption, not proof that the lull uniquely caused that interruption. Paired no-lull contrasts are supplied.','', '| Condition, d=0.25 | Group | Suppressed / 100 eligible weeks | Suppressed share of NC flags | NC / CAP detected (pooled) | Lost positive events |','|---|---|---:|---:|---:|---:|']
for q,s in selected:
 for group in ['control','positive']:
  r=next(r for r in agg if r['seed']==20261015 and r['d']==.25 and r['q']==q and r['s']==s and r['window']=='to_end' and r['group']==group)
  lines.append(f"| q={q}, multiplier={s} | {group} | {r['suppressed_per100']:.2f} | {r['suppression_fraction']:.3f} | {r['pooled_nc_detected']} / {r['pooled_cap_detected']} | {r['pooled_lost'] if group=='positive' else 'NA'} |")
lines+=['','Control “detected” columns mean controls flagged inside their declared anchor windows, not true-positive detections. Eligible diagnostic weeks are 7–20 (14 weeks); the first possible default p=3 flag is week 9. All 20 weeks remain in canonical event scoring. Positive events may be flagged at onset if a run began before onset.','', '## Verification and interpretation limits','']
manifest=json.loads((R/'mechanism_data_manifest.json').read_text());lines+=['```json',json.dumps(manifest['checks'],indent=2),'```','',f"Completed {len(a2)} condition/seed/window matched-rate comparisons. Full 28-condition results and 11 seeds are retained; no selective replacement of the original experiment.",'','- Canonical defaults reproduced exactly for CAP and no-context in every evaluated condition and seed. Archived integer counts, including pre-onset and strict counts, matched.','- CAP flags are a subset of no-context flags; current plus earlier interruption accounts for suppression; CAP never produces an earlier first post-onset alert than no-context among jointly detected events.','- Strict detection is a composite excluding pre-onset-flagged events, not the uniquely correct score and not a speed metric.','- The factorial table contains all four context on/off × p=1/3 combinations. Paired contrasts and timing cross-cells support examining persistence without inferring its role from lull duration alone.','- Descriptive equal-presentation averages are primary; pooled counts are separately labeled. Zero denominators are NA. Seeds overlap in participants and are not independent replication.','- The finite threshold grid does not exhaust all possible rules or settings. Matched test-set frontiers do not validate prospective workload control.','- No inference that suppressed control flags were false alarms, staff time was saved, real disengagement was detected, or novelty was definitively established.','- This was run in the existing environment, with exact versions recorded. It is not the separate clean-environment rebuild.','- Manuscript v5 is unchanged pending interpretation of these findings.','', '## Files and reproduction','', 'Run `python code/run_mechanism.py --package PATH_TO_EXTENSION_PACKAGE --database PATH_TO_DB --registration PATH_TO_REGISTRATION --assignments PATH_TO_ORIGINAL_ASSIGNMENTS --private-output PRIVATE_DIRECTORY`, then `python code/summarize.py`. Use the environment versions in `requirements-lock.txt`. Input content hashes are recorded in `mechanism_data_manifest.json`. Obtain data and private assignments separately. No raw inputs or identifiers are included in this public analysis package.']
(R/'Mechanism_Analysis_Report.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[:35]))
