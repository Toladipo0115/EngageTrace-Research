"""Descriptive reporting of prespecified outputs; does not alter analysis settings."""
import csv,collections,statistics,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def rd(n):
 rows=list(csv.DictReader(open(R/'results'/n)))
 for r in rows:
  for k,v in r.items():
   if not v:r[k]=None
   else:
    try:r[k]=float(v)
    except ValueError:pass
 return rows
mean=statistics.mean
agg=rd('mechanism_aggregate_table.csv');a2=rd('A2_matched_control_comparison.csv');paired=rd('paired_lull_contrasts.csv');timing=rd('mechanism_timing_table.csv');factor=rd('factorial_presentation_table.csv')
L=['','## Direct answers from this execution','','The following are descriptive comparisons on already examined data. Differences do not establish general superiority or equivalence.','', '### Does context outperform simply tightening the individual cutoff?','','For d=0.25 and the primary window:']
for q,s in [(0,None),(2,.5),(4,.25)]:
 rr=[r for r in a2 if r['d']==.25 and r['q']==q and r['s']==s and r['window']=='to_end'];r=next(r for r in rr if r['seed']==20261015)
 dif=[x['cap_minus_nc_feasible'] for x in rr];di=[x['cap_minus_nc_interpolated'] for x in rr]
 L.append(f"- q={q}, multiplier={s}: CAP minus best tested budget-feasible no-context detection = {100*r['cap_minus_nc_feasible']:+.2f} percentage points in the original seed. Across 11 overlapping seeds: {100*min(dif):+.2f} to {100*max(dif):+.2f} points; CAP higher in {sum(v>1e-12 for v in dif)}/11. Relative to the interpolated no-context point: {100*r['cap_minus_nc_interpolated']:+.2f} points in the original seed, range {100*min(di):+.2f} to {100*max(di):+.2f}.")
L+=['','A positive difference against a budget-feasible grid point can reflect threshold-grid slack. Check the achieved control rates and interpolated comparison before attributing it to context. A negative result in a tested setting rules out a CAP detection advantage there at this reference budget; it does not establish equivalence across methods or all thresholds.','', '### What disappears, and when?','']
for q,s in [(0,None),(2,.5),(4,.25)]:
 rr=[r for r in agg if r['seed']==20261015 and r['d']==.25 and r['q']==q and r['s']==s and r['window']=='to_end']
 for r in rr:
  current=r['current_rank'];carry=r['prior_rank'];den=current+carry
  L.append(f"- q={q}, multiplier={s}, {r['group']}: {100*current/den:.1f}% of suppressed weekly flags fail rank in that week and {100*carry/den:.1f}% are persistence-mediated earlier-rank interruptions. Suppression = {r['suppressed_per100']:.2f} flags per 100 eligible weeks.")
  if r['group']=='positive':L.append(f"  Of {r['pooled_nc_detected']:.0f} no-context-detected positive events, CAP retains {r['pooled_cap_detected']:.0f} and loses {r['pooled_lost']:.0f}. Equal-presentation fractions among NC-detected events: same first week {r['same_first_nc_detected_fraction']:.3f}, later first week {r['later_first_nc_detected_fraction']:.3f}, undetected {r['lost_nc_detected_fraction']:.3f}.")
 if q:
  ps=[r for r in paired if r['seed']==20261015 and r['d']==.25 and r['q']==q and r['s']==s and r['window']=='to_end']
  for group in ['control','positive']:
   rr=[r for r in ps if r['group']==group];L.append(f"  Paired {group} excess suppression over no lull: {mean([r['excess_suppressed_per100'] for r in rr]):+.2f} flags per 100 eligible weeks. Range across eight presentations: {min(r['excess_suppressed_per100'] for r in rr):+.2f} to {max(r['excess_suppressed_per100'] for r in rr):+.2f}.")
L+=['','### Does persistence change the response to the short lull?','','Paired changes below are in the proportion of control students flagged in their declared primary anchor windows, d=0.25, original seed. They are not false-positive rates.','', '| Context | Persistence | No-lull control rate | Two-week × 0.50 control rate | Difference (points) |','|---|---:|---:|---:|---:|']
for context in [0,1]:
 for p in [1,3]:
  vals=[]
  for q,s in [(0,None),(2,.5)]:
   rr=[r for r in factor if r['seed']==20261015 and r['d']==.25 and r['q']==q and r['s']==s and r['window']=='to_end' and r['group']=='control' and r['context']==context and r['p']==p];vals.append(mean([r['alarm']/r['n'] for r in rr]))
  L.append(f"| {bool(context)} | {p} | {vals[0]:.3f} | {vals[1]:.3f} | {100*(vals[1]-vals[0]):+.2f} |")
L+=['','These paired factorial differences examine the persistence explanation directly. They do not prove that any lull shorter than p cannot create an alert: natural activity, pre-existing runs and lagged-baseline effects remain part of these real traces.','', '### What this changes in the paper','','The analysis can support a precise description of how rank failures interrupt runs and alter event retention and timing. The matched-rate results must determine whether the paper can claim any observed advantage over a stricter individual cutoff in a particular condition. Do not infer a useful trade-off solely from the number of flags removed. Keep outcomes unfavorable to CAP and retain the exploratory label. Practical usefulness, authentic false-alarm reduction, new-data generalization and the sufficiency of novelty for publication remain unresolved.']
with (R/'Mechanism_Analysis_Report.md').open('a') as f:f.write('\n'.join(L)+'\n')
print('\n'.join(L[:12]))
