import sys,argparse,json,csv,hashlib,collections
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--package',required=True);ap.add_argument('--database',required=True);ap.add_argument('--registration',required=True);a=ap.parse_args();sys.path.insert(0,str(Path(a.package).resolve()/'code'))
import common as C
from fastdet import feats,ge,persist,f_cap
C.DB=a.database;C.REG=a.registration
data,_=C.frozen_pools();proto=json.loads((R/'mechanism_protocol.json').read_text());rows=[];verification=0
for seed in proto['seeds']:
 for d,q,s in C.condition_list():
  pieces=[]
  for course,pool in sorted(data.items()):
   ids,scen=C.sample_assignment(pool,course,seed);mat=C.inject(pool,ids,scen,q,s,d);F=feats(np.array([mat[i] for i in ids],float));cap=f_cap(F)
   z=np.full_like(F['ld'],-np.inf)
   for t in range(2,20):z[:,t]=np.min(np.nan_to_num(F['ld'][:,t-2:t+1],nan=-np.inf),axis=1)
   on=np.array([C.ONSETS[x] for x in scen]);pos=np.array([x in C.POS for x in scen]);pieces.append((course,F,cap,z,on,pos))
  for window in ['to_end','six_week']:
   sc=[];po=[];cp=[];private=[]
   for course,F,cap,z,on,pos in pieces:
    end=np.full(300,20) if window=='to_end' else np.minimum(on+5,20);week=np.arange(1,21)[None,:];win=(week>=on[:,None])&(week<=end[:,None]);scores=np.where(win,z,-np.inf).max(1);ca=(cap&win).any(1)
    sc.extend(scores);po.extend(pos);cp.extend(ca);private.append((F,win,scores,pos))
   scores=np.array(sc);pos=np.array(po);capalarm=np.array(cp);target=int(capalarm[~pos].sum());ctrlscores=np.sort(scores[~pos])[::-1];assert len(ctrlscores)==1440
   if (ctrlscores>=0).sum()<=target:threshold=0.
   else:threshold=float(max(0.,np.nextafter(ctrlscores[target],np.inf)))
   out=scores>=threshold;assert out[~pos].sum()<=target
   for F,win,z,poslocal in private:
    direct=(persist(ge(F['ld'],threshold),3)&win).any(1);assert np.array_equal(direct,z>=threshold);verification+=300
   rows.append(dict(seed=seed,d=d,q=q,s=s,window=window,cap_control_count=target,cap_detection_count=int(capalarm[pos].sum()),nc_exact_threshold=threshold,nc_control_count=int(out[~pos].sum()),nc_detection_count=int(out[pos].sum()),n_positive=960,n_control=1440,cap_minus_nc_detection=(capalarm[pos].sum()-out[pos].sum())/960,control_budget_slack=(target-out[~pos].sum())/1440))
 print('Exact audit seed',seed,flush=True)
with (R/'results/A2_exact_no_context_frontier.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(R/'exact_frontier_checks.json').write_text(json.dumps(dict(status='completed',event_predicates_verified=verification,comparisons=len(rows),coarse_outcomes_inspected_before_amendment=True),indent=2))
for q,s in [(0,None),(2,.5),(4,.25)]:
 rr=[r for r in rows if r['d']==.25 and r['q']==q and r['s']==s and r['window']=='to_end'];r=next(r for r in rr if r['seed']==20261015);print(q,s,r,'range',min(x['cap_minus_nc_detection'] for x in rr),max(x['cap_minus_nc_detection'] for x in rr),flush=True)
