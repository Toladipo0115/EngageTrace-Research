"""Run the frozen post hoc plan. See README for inputs; all source files read-only."""
import argparse,csv,gzip,hashlib,json,sys,platform,time,importlib.metadata
from pathlib import Path
from collections import defaultdict
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--package',required=True);ap.add_argument('--database',required=True);ap.add_argument('--registration',required=True);ap.add_argument('--assignments',required=True);ap.add_argument('--private-output',required=True);a=ap.parse_args()
pkg=Path(a.package).resolve();sys.path.insert(0,str(pkg/'code'))
import common as C
from fastdet import feats,persist,ge,f_cap,f_noctx
C.DB=a.database;C.REG=a.registration
proto=json.loads((ROOT/'mechanism_protocol.json').read_text());assert hashlib.sha256((ROOT/'mechanism_protocol.json').read_bytes()).hexdigest()==(ROOT/'mechanism_protocol.sha256').read_text().split()[0]
C.check_protocol_hash();private=Path(a.private_output);private.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
manifest=dict(status='started',python=sys.version,platform=platform.platform(),packages={n:importlib.metadata.version(n) for n in ['numpy','scipy','matplotlib']},inputs={Path(p).name:sha(p) for p in [a.database,a.registration,a.assignments,__file__,ROOT/'mechanism_protocol.json',pkg/'code/fastdet.py',pkg/'code/common.py',pkg/'vendor/engagetrace_detectors.py',pkg/'vendor/run_validation.py']})
(ROOT/'mechanism_data_manifest.json').write_text(json.dumps(manifest,indent=2))
data,counts=C.frozen_pools();print('Eligibility',counts,flush=True)
arch=defaultdict(list)
for r in csv.DictReader(open(a.assignments)):
 if r['quiet_length']=='2':arch[r['course']].append((r['student'],r['scenario']))
thresholds=proto['A2']['thresholds'];conds=C.condition_list();metrics=[];times=[];factor=[];sweeps=[];paired=[];checks=dict(canonical_cells_per_method=0,canonical_mismatches=0,grid_integer_checks=0,subset_failures=0,partition_failures=0,earlier_alert_failures=0,assignment_presentations_checked=0)
windows=['to_end','six_week'];ts=np.arange(1,21);eligible=ts>=7

def masks(scen,window):
 on=np.array([C.ONSETS[x] for x in scen]);end=np.full(300,20) if window=='to_end' else np.minimum(on+5,20)
 win=(ts[None,:]>=on[:,None])&(ts[None,:]<=end[:,None]);pre=ts[None,:]<on[:,None]
 pos=np.array([x in C.POS for x in scen]);return win,pre,pos,on

def score(arr,scen,window):
 win,pre,pos,on=masks(scen,window)
 return (arr&win).any(1),(arr&pre).any(1),pos

def val(n,d):return float(n/d) if d else None

def flat_write(name,rows):
 with (ROOT/'results'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

start=time.monotonic()
for seed in proto['seeds']:
 archived={}
 for r in C.read_rows(pkg/'results'/f'grid_seed_{seed}.csv.gz'):
  if r['method'] in ['cap','cap_no_context']:
   archived[(r['course'],r['d'],r['q'],r['s'],r['method'],r['window'],r['scenario'])]=tuple(r[x] for x in ['n','alarm','pre','strict'])
 for course,pool in sorted(data.items()):
  ids,scen=C.sample_assignment(pool,course,seed)
  if seed==20261015:assert list(zip(ids,scen))==arch[course];checks['assignment_presentations_checked']+=1
  base={}
  for d,q,s in conds:
   mat=C.inject(pool,ids,scen,q,s,d);M=np.array([mat[i] for i in ids],dtype=float);F=feats(M);ind=ge(F['ld'],.2);rank=ge(F['rank'],.6)
   nc=persist(ind,3);cap=persist(ind&rank,3)
   canonical=C.detect_revised(mat,C.RevisedConfig(**C.DET))
   for method,arr in [('cap',cap),('cap_no_context',nc)]:
    ref=np.array([canonical[i][method] for i in ids]);bad=int((arr!=ref).sum());checks['canonical_mismatches']+=bad;checks['canonical_cells_per_method']+=arr.size//2
    assert bad==0
    for window in windows:
     alarm,pre,pos=score(arr,scen,window)
     for sc in C.SCENARIOS:
      g=np.array([x==sc for x in scen]);got=(int(g.sum()),int(alarm[g].sum()),int(pre[g].sum()),int((alarm&~pre)[g].sum()))
      assert got==archived[(course,d,q,s,method,window,sc)],(seed,course,d,q,s,method,window,sc)
      checks['grid_integer_checks']+=4
   sup=nc&~cap;current=sup&~rank;prior=np.zeros_like(sup);inside=np.zeros_like(sup);outside=np.zeros_like(sup)
   for lag in [1,2]:
    fail=np.zeros_like(sup);fail[:,lag:]=~rank[:,:-lag]&ind[:,:-lag]
    prior|=fail
    h=ts-lag;inside|=fail&((h>=7)&(h<7+q))[None,:] if q else np.zeros_like(fail)
    outside|=fail&(~((h>=7)&(h<7+q)))[None,:] if q else fail
   carry=sup&rank&prior
   assert not (cap&~nc).any();assert np.array_equal(sup,current|carry);assert not (current&carry).any()
   assert not nc[:,:8].any() and not cap[:,:8].any()
   groups={'positive':np.array([x in C.POS for x in scen]),'control':np.array([x not in C.POS for x in scen])}
   key=dict(seed=seed,presentation=course,d=d,q=q,s=s)
   local={}
   for window in windows:
    win,pre,pos,on=masks(scen,window);da=(nc&win).any(1);db=(cap&win).any(1);pa=(nc&pre).any(1);pb=(cap&pre).any(1)
    ta=np.where(nc&win,ts[None,:],99).min(1);tb=np.where(cap&win,ts[None,:],99).min(1)
    assert not (db&~da).any();assert not (db&(tb<ta)).any()
    for group,g in groups.items():
     aa=da[g];bb=db[g];joint=aa&bb;delta=(tb-ta)[g][joint];n=int(g.sum());ncw=int(nc[g][:,eligible].sum());sp=int(sup[g][:,eligible].sum())
     row=dict(**key,window=window,group=group,n=n,eligible_weeks=n*14,nc_flagged_weeks=ncw,suppressed_weeks=sp,current_rank=int(current[g][:,eligible].sum()),prior_rank=int(carry[g][:,eligible].sum()),prior_lull_only=int((carry&inside&~outside)[g][:,eligible].sum()),prior_outside_only=int((carry&outside&~inside)[g][:,eligible].sum()),prior_mixed=int((carry&inside&outside)[g][:,eligible].sum()),suppression_fraction=val(sp,ncw),suppressed_per100=100*sp/(n*14),nc_detected=int(aa.sum()),cap_detected=int(bb.sum()),nc_pre=int(pa[g].sum()),cap_pre=int(pb[g].sum()),nc_strict=int((da&~pa)[g].sum()),cap_strict=int((db&~pb)[g].sum()),same_first=int((joint&(tb[g]==ta[g])).sum()) if group=='positive' else None,later_first=int((joint&(tb[g]>ta[g])).sum()) if group=='positive' else None,lost=int((aa&~bb).sum()) if group=='positive' else None,neither=int((~aa&~bb).sum()) if group=='positive' else None,delay_median=float(np.median(delta)) if len(delta) and group=='positive' else None,delay_q25=float(np.quantile(delta,.25)) if len(delta) and group=='positive' else None,delay_q75=float(np.quantile(delta,.75)) if len(delta) and group=='positive' else None)
     metrics.append(row);local[(window,group)]=row
   # Full four-cell factorial, on identical log-decline features.
   for context in [False,True]:
    for persistence in [1,3]:
     flags=persist(ind&(rank if context else True),persistence)
     for window in windows:
      da,pa,pos=score(flags,scen,window)
      for group,g in groups.items():
       factor.append(dict(**key,window=window,group=group,context=int(context),p=persistence,n=int(g.sum()),alarm=int(da[g].sum()),pre=int(pa[g].sum()),strict=int((da&~pa)[g].sum()),flagged_weeks=int(flags[g][:,eligible].sum()),in_lull=int(flags[g][:, (ts>=7)&(ts<7+q)].sum()) if q else 0,post_lull1=int(flags[g][:,ts==7+q].sum()) if q else None,post_lull2=int(flags[g][:,ts==8+q].sum()) if q else None))
   # All weekly timing cross-cells, primary seed only; no IDs in aggregate.
   if seed==20261015:
    lp=np.array(['no_lull']*20,dtype=object) if not q else np.array(['pre_lull' if t<7 else 'in_lull' if t<7+q else 'post_lull1' if t==7+q else 'post_lull2' if t==8+q else 'post_lull3plus' for t in ts])
    for sc in C.SCENARIOS:
     g=np.array([x==sc for x in scen]);on=C.ONSETS[sc];ep=np.array(['pre_onset' if t<on else 'onset_to2' if t<=on+2 else 'onset3plus' for t in ts]) if sc in C.POS else np.array(['before_anchor' if t<on else 'at_or_after_anchor' for t in ts])
     for l,e in sorted(set(zip(lp[eligible],ep[eligible]))):
      tm=eligible&(lp==l)&(ep==e);times.append(dict(**key,scenario=sc,lull_position=l,event_or_anchor_position=e,eligible_weeks=int(g.sum()*tm.sum()),nc_weeks=int(nc[g][:,tm].sum()),suppressed=int(sup[g][:,tm].sum()),current=int(current[g][:,tm].sum()),carry=int(carry[g][:,tm].sum())))
    np.savez_compressed(private/f'diagnostics_{course}_d{d}_q{q}_s{s}.npz',ids=np.array(ids),scenario=np.array(scen),log_decline=F['ld'],rank=F['rank'],individual=ind,cap=cap,no_context=nc,current=current,carry=carry)
   if q==0:base[d]=local
   else:
    for wk,row in local.items():
     r0=base[d][wk];paired.append(dict(**key,window=wk[0],group=wk[1],excess_suppressed_per100=row['suppressed_per100']-r0['suppressed_per100'],delta_nc_detected=row['nc_detected']-r0['nc_detected'],delta_cap_detected=row['cap_detected']-r0['cap_detected'],delta_lost=(row['lost']-r0['lost']) if wk[1]=='positive' else None))
   for threshold in thresholds:
    for method,flags in [('cap',f_cap(F,ti=threshold)),('no_context',f_noctx(F,ti=threshold))]:
     for window in windows:
      da,pa,pos=score(flags,scen,window)
      sweeps.append(dict(**key,threshold=threshold,method=method,window=window,npos=int(pos.sum()),nctrl=int((~pos).sum()),pos=int(da[pos].sum()),ctrl=int(da[~pos].sum()),pos_pre=int(pa[pos].sum()),strict=int((da&~pa)[pos].sum())))
  print('Completed',seed,course,'seconds',round(time.monotonic()-start,1),flush=True)
 for name,rows in [('mechanism_presentation_table.csv',metrics),('mechanism_timing_table.csv',times),('factorial_presentation_table.csv',factor),('paired_lull_contrasts.csv',paired),('threshold_sweep_presentation.csv',sweeps)]:flat_write(name,rows)
manifest.update(status='completed',eligibility=counts,checks=checks,elapsed_seconds=time.monotonic()-start)
(ROOT/'mechanism_data_manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(checks),flush=True)
