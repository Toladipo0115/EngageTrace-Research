import sys,csv,json,argparse
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--package',required=True);ap.add_argument('--database',required=True);ap.add_argument('--registration',required=True);a=ap.parse_args();sys.path.insert(0,str(Path(a.package).resolve()/'code'))
import common as C
from fastdet import feats,f_noctx
C.DB=a.database;C.REG=a.registration;data,_=C.frozen_pools();n=0
for row in csv.DictReader(open(R/'results/A2_exact_no_context_frontier.csv')):
 if int(row['seed'])!=20261015:continue
 for course,pool in sorted(data.items()):
  ids,scen=C.sample_assignment(pool,course,20261015);q=int(row['q']);s=float(row['s']) if row['s'] else None;d=float(row['d']);tau=float(row['nc_exact_threshold']);mat=C.inject(pool,ids,scen,q,s,d)
  cfg=dict(C.DET,tau_ind_log=tau);canonical=C.detect_revised(mat,C.RevisedConfig(**cfg));fast=f_noctx(feats(np.array([mat[i] for i in ids],float)),ti=tau);ref=np.array([canonical[i]['cap_no_context'] for i in ids]);assert np.array_equal(fast,ref);n+=fast.size
p=R/'exact_frontier_checks.json';j=json.loads(p.read_text());j['original_seed_selected_threshold_canonical_cells']=n;j['selected_threshold_canonical_mismatches']=0;p.write_text(json.dumps(j,indent=2));print(j)
