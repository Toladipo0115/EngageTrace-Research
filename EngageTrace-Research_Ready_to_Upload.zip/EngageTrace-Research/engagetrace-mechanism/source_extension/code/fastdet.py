"""Vectorised detectors with tunable thresholds. Equivalence with the vendored canonical detectors at the frozen
settings is tested by test_equivalence.py (zero mismatches required)."""
import math
import numpy as np

def feats(M, k=3, lag=3):
    n, T = M.shape
    L = np.fromiter((math.log1p(v) for v in M.ravel()), dtype=float, count=M.size).reshape(M.shape)   # math.log1p matches canonical ties
    ld = np.full(M.shape, np.nan); rd = np.full(M.shape, np.nan); rank = np.full(M.shape, np.nan)
    for t in range(k + lag, T):
        lb = np.median(L[:, t - k - lag:t - lag], axis=1); ld[:, t] = lb - L[:, t]
        rb = np.median(M[:, t - k - lag:t - lag], axis=1); rd[:, t] = (rb - M[:, t]) / (rb + 1e-6)
        col = np.sort(ld[:, t]); rank[:, t] = np.searchsorted(col, ld[:, t], side='right') / n   # focal included, upper rank
    return dict(ld=ld, rd=rd, rank=rank, M=M, k=k)

def persist(cond, p):
    run = np.zeros(cond.shape[0]); out = np.zeros(cond.shape, dtype=bool)
    for t in range(cond.shape[1]):
        run = (run + 1) * cond[:, t]; out[:, t] = run >= p
    return out

def ge(a, th):
    with np.errstate(invalid='ignore'): return np.nan_to_num(a, nan=-1e9) >= th

def f_cap(F, ti=0.2, tc=0.6, p=3): return persist(ge(F['ld'], ti) & ge(F['rank'], tc), p)
def f_noctx(F, ti=0.2, p=3): return persist(ge(F['ld'], ti), p)
def f_raw(F, tr=0.5, p=3): return persist(ge(F['rd'], tr), p)
def f_fixed(F, th=6, p=3): return persist(F['M'] < th, p)

def f_cusum(F, H=2.0, allowance=0.25):
    M = F['M']; k = F['k']; mu = np.median(M[:, :k], axis=1); S = np.zeros(M.shape[0]); out = np.zeros(M.shape, dtype=bool)
    for t in range(M.shape[1]):
        S = np.maximum(0, S + (mu - M[:, t]) - allowance * mu); out[:, t] = (S > H * mu) & (mu > 0)
    return out

def _fp(total, exposure):
    return 0.0 if total == 0 else total * math.log(total / exposure) - total

def poisson_stats(M):
    """Statistic 2(best-null) and downward flag per student and week, as in the vendored Poisson adaptation."""
    n, T = M.shape; means = M.mean(axis=0); expo = [0.0]
    for v in means: expo.append(expo[-1] + float(v))
    stat = np.full(M.shape, -np.inf); down = np.zeros(M.shape, dtype=bool)
    for i in range(n):
        sums = [0]
        for v in M[i]: sums.append(sums[-1] + int(v))
        for t in range(2, T + 1):
            total = sums[t]; E = expo[t]
            if not total or not E: continue
            null = _fp(total, E); best = -math.inf; rates = None
            for split in range(1, t):
                a = sums[split]; b = total - a; ea = expo[split]; eb = E - ea
                ll = _fp(a, ea) + _fp(b, eb)
                if ll > best: best = ll; rates = (a / ea if ea else 0.0, b / eb if eb else 0.0)
            stat[i, t - 1] = 2 * (best - null); down[i, t - 1] = rates[1] < rates[0]
    return dict(stat=stat, down=down, T=T)

def f_poisson(P, c=1.0):
    T = P['T']; thr = np.array([c * 2 * math.log(t) for t in range(1, T + 1)])
    return (P['stat'] > thr[None, :]) & P['down']
