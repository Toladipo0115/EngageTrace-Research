"""Experiment 2: development-only threshold selection at prespecified control flag budgets, then frozen evaluation.
Run: python3 calibrate.py   (needs ET_DB, ET_REG). Writes results/exp2_*.json/csv"""
import sqlite3, json, csv
import numpy as np
from common import *
from fastdet import *

check_protocol_hash()
P2 = PROTO['experiment_2_calibration']; G = P2['grids']; BUDGETS = P2['budgets']
DEV_COURSES = ['BBB_2013J', 'BBB_2014J', 'CCC_2014J', 'DDD_2013J', 'FFF_2013J', 'FFF_2014J']
DEV_SEEDS = [101, 202, 303, 404, 505]
D, S, Q = 0.25, 0.5, 2

def dev_pools():
    """Original eligibility filters (registered by day 0, no withdrawal before day 140, nonzero clicks) applied to the
    six development presentations, no purge of earlier presentations; cross-presentation duplicates removed once."""
    regs = list(csv.DictReader(open(REG))); elig = defaultdict(list)
    for r in regs:
        c = r['code_module'] + '_' + r['code_presentation']
        if c not in DEV_COURSES: continue
        if r['date_registration'] in ('', '?') or int(r['date_registration']) > 0: continue
        if r['date_unregistration'] not in ('', '?') and int(r['date_unregistration']) < 140: continue
        elig[c].append(r['id_student'])
    data = {}
    with sqlite3.connect(f'file:{Path(DB).resolve()}?mode=ro', uri=True) as con:
        for c, ids in sorted(elig.items()):
            m = {s: [0] * 20 for s in ids}
            for sid, w, x in con.execute('SELECT student_id,week,clicks FROM weekly_activity WHERE course_id=? AND week BETWEEN 1 AND 20', (c,)):
                if sid in m: m[sid][w - 1] = x
            for s in list(m):
                if not sum(m[s]): del m[s]
            data[c] = m
    seen = set()
    for c, pool in sorted(data.items()):
        for s in list(pool):
            if s in seen: del pool[s]
            else: seen.add(s)
    assert all(len(p) >= 300 for p in data.values()), {c: len(p) for c, p in data.items()}
    return data

def settings():
    out = []
    for th in range(1, 31): out.append(('fixed', dict(threshold=th)))
    for t in G['individual']['tau']: out.append(('individual', dict(tau=t)))
    for t in G['no_context']['tau_ind']: out.append(('cap_no_context', dict(tau_ind=t)))
    for ti in G['cap']['tau_ind']:
        for tc in G['cap']['tau_ctx']: out.append(('cap', dict(tau_ind=ti, tau_ctx=tc)))
    for h in G['cusum']['H_multiple_of_mu0']: out.append(('cusum', dict(H=h)))
    for c in G['park_prefix_poisson']['penalty_multiplier_c']: out.append(('park_prefix_poisson', dict(c=c)))
    return out
SET = settings()

def flags_for(method, par, F, P):
    if method == 'fixed': return f_fixed(F, par['threshold'])
    if method == 'individual': return f_raw(F, par['tau'])
    if method == 'cap_no_context': return f_noctx(F, par['tau_ind'])
    if method == 'cap': return f_cap(F, par['tau_ind'], par['tau_ctx'])
    if method == 'cusum': return f_cusum(F, par['H'])
    if method == 'park_prefix_poisson': return f_poisson(P, par['c'])

def score_arr(fl, scen, window):
    """Returns detection hits, positives, control flags, controls."""
    ph = pn = ch = cn = 0
    for row, c in zip(fl, scen):
        a, _, _ = score_case(row.tolist(), ONSETS[c], window)
        if c in POS: ph += a; pn += 1
        else: ch += a; cn += 1
    return ph, pn, ch, cn

def score_group(fl, scen, window):
    acc = defaultdict(lambda: [0, 0])
    for row, c in zip(fl, scen):
        a, _, _ = score_case(row.tolist(), ONSETS[c], window); acc[c][0] += a; acc[c][1] += 1
    return {c: v[0] / v[1] for c, v in acc.items()}

def unit_matrix(pool, ids, scen, q):
    mat = inject(pool, ids, scen, q, S, D)
    return np.array([mat[s] for s in ids], dtype=float)

def main():
    res = ROOT / 'results'; res.mkdir(exist_ok=True)
    dev = dev_pools(); dev_n = {c: len(p) for c, p in dev.items()}
    # development table: setting x unit -> (det, ctrl)
    det = np.zeros((len(SET), 0)); units = []; cols_d = []; cols_c = []
    for c, pool in sorted(dev.items()):
        for sd in DEV_SEEDS:
            ids, scen = sample_assignment(pool, c, sd); M = unit_matrix(pool, ids, scen, Q)
            F = feats(M); Pz = poisson_stats(M); d_, c_ = [], []
            for m, par in SET:
                ph, pn, ch, cn = score_arr(flags_for(m, par, F, Pz), scen, 'to_end'); d_.append(ph / pn); c_.append(ch / cn)
            cols_d.append(d_); cols_c.append(c_); units.append((c, sd))
    DD = np.array(cols_d).T; CC = np.array(cols_c).T          # settings x units (30)
    # equal weight: mean within presentation over seeds, then across presentations
    def eq(A):
        return np.mean([A[:, [i for i, u in enumerate(units) if u[0] == c]].mean(axis=1) for c in sorted(dev)], axis=0)
    dev_det, dev_ctrl = eq(DD), eq(CC)
    table = [dict(method=m, **{f'param_{k}': v for k, v in par.items()}, dev_detection=float(dev_det[i]), dev_control_flag_rate=float(dev_ctrl[i])) for i, (m, par) in enumerate(SET)]
    with open(res / 'exp2_development_grid.csv', 'w', newline='') as f:
        keys = sorted({k for r in table for k in r}, key=lambda k: (k != 'method', k)); w = csv.DictWriter(f, keys); w.writeheader(); w.writerows(table)
    # selection
    sel = {}
    for b in BUDGETS:
        for m in ['fixed', 'individual', 'cap_no_context', 'cap', 'cusum', 'park_prefix_poisson']:
            idx = [i for i, (mm, _) in enumerate(SET) if mm == m and dev_ctrl[i] <= b + 1e-12]
            if not idx: sel[(b, m)] = None; continue
            best = min(idx, key=lambda i: (-dev_det[i], dev_ctrl[i], i)); sel[(b, m)] = best
    # frozen evaluation on archived frozen assignments
    data, _ = frozen_pools(); out = []
    for b in BUDGETS:
        for m in ['fixed', 'individual', 'cap_no_context', 'cap', 'cusum', 'park_prefix_poisson']:
            i = sel[(b, m)]
            if i is None:
                out.append(dict(budget=b, method=m, selected=None)); continue
            par = SET[i][1]; rec = dict(budget=b, method=m, params=par, dev_detection=float(dev_det[i]), dev_control_flag_rate=float(dev_ctrl[i]), test={})
            for q in (0, 2, 4):
                per = {w: {} for w in ('to_end', 'six_week')}
                for c in sorted(data):
                    ids, scen = archived_assignment(c)
                    M = unit_matrix(data[c], ids, scen, q); F = feats(M); Pz = poisson_stats(M) if m == 'park_prefix_poisson' else None
                    fl = flags_for(m, par, F, Pz)
                    for w in per:
                        ph, pn, ch, cn = score_arr(fl, scen, w); g = score_group(fl, scen, w)
                        per[w][c] = dict(detection=ph / pn, control_flag_rate=ch / cn, **{f'rate_{k}': v for k, v in g.items()})
                rec['test'][f'q{q}'] = {w: dict(equal_weight_detection=float(np.mean([v['detection'] for v in per[w].values()])),
                                                 equal_weight_control_flag_rate=float(np.mean([v['control_flag_rate'] for v in per[w].values()])),
                                                 per_presentation=per[w]) for w in per}
            out.append(rec)
    (res / 'exp2_calibration.json').write_text(json.dumps(dict(protocol_sha256=(ROOT / 'protocol' / 'protocol.sha256').read_text().split()[0],
        dev_presentation_pool_sizes=dev_n, dev_units=len(units), note='Frozen presentations already examined; not untouched confirmation. No interpolation.', results=out), indent=1))
    # compact view
    for r in out:
        if r.get('selected', 1) is None: print(r['budget'], r['method'], 'not attainable'); continue
        t = r['test']
        print(f"b={r['budget']:.2f} {r['method']:<20} {json.dumps(r['params']):<34} dev {r['dev_detection']:.2f}/{r['dev_control_flag_rate']:.2f} | test q2 end {t['q2']['to_end']['equal_weight_detection']:.2f}/{t['q2']['to_end']['equal_weight_control_flag_rate']:.2f} q0 {t['q0']['to_end']['equal_weight_detection']:.2f}/{t['q0']['to_end']['equal_weight_control_flag_rate']:.2f} q4 {t['q4']['to_end']['equal_weight_detection']:.2f}/{t['q4']['to_end']['equal_weight_control_flag_rate']:.2f}")
main()
