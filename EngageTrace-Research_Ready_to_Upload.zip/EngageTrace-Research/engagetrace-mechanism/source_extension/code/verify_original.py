"""Reproduce the original frozen summary.csv from the extension grid at d=0.25, s=0.5, q in {2,4}."""
from analysis import *
rows = load_grid([20261015]); pr = presentation_rates(course_table(rows))
orig = list(csv.DictReader(open(ROOT / 'vendor' / 'original_summary.csv')))
worst = 0; n = 0
for o in orig:
    q = int(o['quiet_length']); m = o['method']; w = o['window']; g = 'pos' if o['group'] == 'positive' else 'ctrl'
    key = (20261015, 0.25, q, 0.5, m, w)
    for idx, col in ((0, 'alarm_rate'), (1, 'pre_onset_alarm_rate'), (2, 'strict_alarm_rate')):
        mine, _ = equal_weight(pr, key, g, idx); diff = abs(mine - float(o[col])); worst = max(worst, diff); n += 1
print('compared', n, 'values; max abs difference', worst)
assert worst < 1e-12
