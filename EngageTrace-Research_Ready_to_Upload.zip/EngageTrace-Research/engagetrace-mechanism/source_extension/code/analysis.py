"""Aggregation helpers: equal weight presentation means from the per-scenario count files."""
from common import *
import numpy as np

def load_grid(seeds):
    rows = []
    for s in seeds: rows += list(read_rows(ROOT / 'results' / f'grid_seed_{s}.csv.gz'))
    return rows

def course_table(rows):
    """key (seed,d,q,s,method,window,course) -> dict of group counts"""
    t = defaultdict(lambda: defaultdict(lambda: [0, 0, 0, 0]))
    for r in rows:
        k = (r['seed'], r['d'], r['q'], r['s'], r['method'], r['window'], r['course'])
        for i, f in enumerate(('n', 'alarm', 'pre', 'strict')):
            t[k][r['scenario']][i] += r[f]
    return t

def rates(groups, names):
    n = sum(groups[g][0] for g in names)
    return tuple(sum(groups[g][i] for g in names) / n for i in (1, 2, 3))  # alarm, pre, strict

GROUPS = {'pos': ['sustained', 'decline_during_quiet'], 'ctrl': ['no_change', 'temporary', 'quiet_only'],
          'ctrl_stable': ['no_change', 'quiet_only'], 'no_change': ['no_change'], 'temporary': ['temporary'], 'quiet_only': ['quiet_only'],
          'sustained': ['sustained'], 'decline_during_quiet': ['decline_during_quiet']}

def presentation_rates(tab):
    """(seed,d,q,s,method,window,course) -> {group: (alarm,pre,strict)}"""
    return {k: {g: rates(v, names) for g, names in GROUPS.items()} for k, v in tab.items()}

def equal_weight(pr, key_wo_course, group, idx=0):
    vals = [v[group][idx] for k, v in pr.items() if k[:-1] == key_wo_course]
    return float(np.mean(vals)), vals

def signflip_p(diffs):
    d = np.array(diffs, float); n = len(d); obs = abs(d.sum())
    cnt = 0
    for signs in itertools.product([1, -1], repeat=n):
        if abs((np.array(signs) * d).sum()) >= obs - 1e-12: cnt += 1
    return cnt / 2 ** n
