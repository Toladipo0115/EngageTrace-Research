# EngageTrace: post hoc mechanism analysis

This analysis was specified after all existing evaluations had been examined. It is explanatory, not independent confirmation. No original detector, sample, threshold default, or result was edited.

## A2: context versus a stricter individual cutoff

Both rules use the same log-decline features, lag and persistence. Rank is fixed at 0.6 for CAP; the individual cutoff is swept over the archived plan’s grid. The table uses default CAP as the control-rate target. The no-context feasible point is the best tested detection at or below that rate. Interpolation is a test-set descriptive construction, not a deployable setting or development-selected threshold.

| Condition, d=0.25 | Window | CAP control | CAP detection | NC feasible control / detection | NC interpolated detection |
|---|---|---:|---:|---:|---:|
| q=0, multiplier=None | to_end | 0.388 | 0.707 | 0.365 / 0.725 | 0.746 |
| q=0, multiplier=None | six_week | 0.261 | 0.633 | 0.254 / 0.653 | 0.661 |
| q=2, multiplier=0.5 | to_end | 0.370 | 0.696 | 0.353 / 0.689 | 0.709 |
| q=2, multiplier=0.5 | six_week | 0.252 | 0.621 | 0.240 / 0.606 | 0.617 |
| q=4, multiplier=0.25 | to_end | 0.309 | 0.604 | 0.303 / 0.547 | 0.549 |
| q=4, multiplier=0.25 | six_week | 0.203 | 0.534 | 0.189 / 0.425 | 0.446 |

## A3: flags, events and timing

Weekly suppression is partitioned into current rank failure and interruption earlier in the three-week run. Categories account for all suppressed flags. A failed rank in a lull is an observed interruption, not proof that the lull uniquely caused that interruption. Paired no-lull contrasts are supplied.

| Condition, d=0.25 | Group | Suppressed / 100 eligible weeks | Suppressed share of NC flags | NC / CAP detected (pooled) | Lost positive events |
|---|---|---:|---:|---:|---:|
| q=0, multiplier=None | control | 8.19 | 0.523 | 849 / 559 | NA |
| q=0, multiplier=None | positive | 10.10 | 0.391 | 792 / 679 | 113 |
| q=2, multiplier=0.5 | control | 8.24 | 0.543 | 790 / 533 | NA |
| q=2, multiplier=0.5 | positive | 9.11 | 0.377 | 778 / 668 | 110 |
| q=4, multiplier=0.25 | control | 11.96 | 0.678 | 710 / 445 | NA |
| q=4, multiplier=0.25 | positive | 9.85 | 0.451 | 719 / 580 | 139 |

Control “detected” columns mean controls flagged inside their declared anchor windows, not true-positive detections. Eligible diagnostic weeks are 7–20 (14 weeks); the first possible default p=3 flag is week 9. All 20 weeks remain in canonical event scoring. Positive events may be flagged at onset if a run began before onset.

## Verification and interpretation limits

```json
{
  "canonical_cells_per_method": 14784000,
  "canonical_mismatches": 0,
  "grid_integer_checks": 197120,
  "subset_failures": 0,
  "partition_failures": 0,
  "earlier_alert_failures": 0,
  "assignment_presentations_checked": 8
}
```

Completed 616 condition/seed/window matched-rate comparisons. Full 28-condition results and 11 seeds are retained; no selective replacement of the original experiment.

- Canonical defaults reproduced exactly for CAP and no-context in every evaluated condition and seed. Archived integer counts, including pre-onset and strict counts, matched.
- CAP flags are a subset of no-context flags; current plus earlier interruption accounts for suppression; CAP never produces an earlier first post-onset alert than no-context among jointly detected events.
- Strict detection is a composite excluding pre-onset-flagged events, not the uniquely correct score and not a speed metric.
- The factorial table contains all four context on/off × p=1/3 combinations. Paired contrasts and timing cross-cells support examining persistence without inferring its role from lull duration alone.
- Descriptive equal-presentation averages are primary; pooled counts are separately labeled. Zero denominators are NA. Seeds overlap in participants and are not independent replication.
- The finite threshold grid does not exhaust all possible rules or settings. Matched test-set frontiers do not validate prospective workload control.
- No inference that suppressed control flags were false alarms, staff time was saved, real disengagement was detected, or novelty was definitively established.
- This was run in the existing environment, with exact versions recorded. It is not the separate clean-environment rebuild.
- Manuscript v5 is unchanged pending interpretation of these findings.

## Files and reproduction

Run `python code/run_mechanism.py --package PATH_TO_EXTENSION_PACKAGE --database PATH_TO_DB --registration PATH_TO_REGISTRATION --assignments PATH_TO_ORIGINAL_ASSIGNMENTS --private-output PRIVATE_DIRECTORY`, then `python code/summarize.py`. Use the environment versions in `requirements-lock.txt`. Input content hashes are recorded in `mechanism_data_manifest.json`. Obtain data and private assignments separately. No raw inputs or identifiers are included in this public analysis package.

## Direct answers from this execution

The following are descriptive comparisons on already examined data. Differences do not establish general superiority or equivalence.

### Does context outperform simply tightening the individual cutoff?

For d=0.25 and the primary window:
- q=0, multiplier=None: CAP minus best tested budget-feasible no-context detection = -1.77 percentage points in the original seed. Across 11 overlapping seeds: -4.79 to -1.77 points; CAP higher in 0/11. Relative to the interpolated no-context point: -3.92 points in the original seed, range -7.77 to -2.29.
- q=2, multiplier=0.5: CAP minus best tested budget-feasible no-context detection = +0.73 percentage points in the original seed. Across 11 overlapping seeds: -2.92 to +0.73 points; CAP higher in 1/11. Relative to the interpolated no-context point: -1.30 points in the original seed, range -5.90 to -0.87.
- q=4, multiplier=0.25: CAP minus best tested budget-feasible no-context detection = +5.73 percentage points in the original seed. Across 11 overlapping seeds: +1.98 to +9.69 points; CAP higher in 11/11. Relative to the interpolated no-context point: +5.50 points in the original seed, range +0.86 to +6.66.

A positive difference against a budget-feasible grid point can reflect threshold-grid slack. Check the achieved control rates and interpolated comparison before attributing it to context. A negative result in a tested setting rules out a CAP detection advantage there at this reference budget; it does not establish equivalence across methods or all thresholds.

### What disappears, and when?

- q=0, multiplier=None, positive: 44.0% of suppressed weekly flags fail rank in that week and 56.0% are persistence-mediated earlier-rank interruptions. Suppression = 10.10 flags per 100 eligible weeks.
  Of 792 no-context-detected positive events, CAP retains 679 and loses 113. Equal-presentation fractions among NC-detected events: same first week 0.580, later first week 0.281, undetected 0.139.
- q=0, multiplier=None, control: 45.4% of suppressed weekly flags fail rank in that week and 54.6% are persistence-mediated earlier-rank interruptions. Suppression = 8.19 flags per 100 eligible weeks.
- q=2, multiplier=0.5, positive: 41.1% of suppressed weekly flags fail rank in that week and 58.9% are persistence-mediated earlier-rank interruptions. Suppression = 9.11 flags per 100 eligible weeks.
  Of 778 no-context-detected positive events, CAP retains 668 and loses 110. Equal-presentation fractions among NC-detected events: same first week 0.617, later first week 0.246, undetected 0.137.
- q=2, multiplier=0.5, control: 46.4% of suppressed weekly flags fail rank in that week and 53.6% are persistence-mediated earlier-rank interruptions. Suppression = 8.24 flags per 100 eligible weeks.
  Paired control excess suppression over no lull: +0.05 flags per 100 eligible weeks. Range across eight presentations: -2.34 to +0.95.
  Paired positive excess suppression over no lull: -0.98 flags per 100 eligible weeks. Range across eight presentations: -2.38 to +0.42.
- q=4, multiplier=0.25, positive: 48.6% of suppressed weekly flags fail rank in that week and 51.4% are persistence-mediated earlier-rank interruptions. Suppression = 9.85 flags per 100 eligible weeks.
  Of 719 no-context-detected positive events, CAP retains 580 and loses 139. Equal-presentation fractions among NC-detected events: same first week 0.605, later first week 0.204, undetected 0.190.
- q=4, multiplier=0.25, control: 53.3% of suppressed weekly flags fail rank in that week and 46.7% are persistence-mediated earlier-rank interruptions. Suppression = 11.96 flags per 100 eligible weeks.
  Paired control excess suppression over no lull: +3.77 flags per 100 eligible weeks. Range across eight presentations: +1.19 to +5.71.
  Paired positive excess suppression over no lull: -0.25 flags per 100 eligible weeks. Range across eight presentations: -4.05 to +2.20.

### Does persistence change the response to the short lull?

Paired changes below are in the proportion of control students flagged in their declared primary anchor windows, d=0.25, original seed. They are not false-positive rates.

| Context | Persistence | No-lull control rate | Two-week × 0.50 control rate | Difference (points) |
|---|---:|---:|---:|---:|
| False | 1 | 0.888 | 0.883 | -0.49 |
| False | 3 | 0.590 | 0.549 | -4.10 |
| True | 1 | 0.865 | 0.861 | -0.42 |
| True | 3 | 0.388 | 0.370 | -1.81 |

These paired factorial differences examine the persistence explanation directly. They do not prove that any lull shorter than p cannot create an alert: natural activity, pre-existing runs and lagged-baseline effects remain part of these real traces.

### What this changes in the paper

The analysis can support a precise description of how rank failures interrupt runs and alter event retention and timing. The matched-rate results must determine whether the paper can claim any observed advantage over a stricter individual cutoff in a particular condition. Do not infer a useful trade-off solely from the number of flags removed. Keep outcomes unfavorable to CAP and retain the exploratory label. Practical usefulness, authentic false-alarm reduction, new-data generalization and the sufficiency of novelty for publication remain unresolved.

## Secondary audit: remove threshold-grid spacing as an explanation

This follow-up was specified after the coarse-grid results had been inspected. Its separate dated and hashed amendment is included. It uses exact event-score boundaries to find the highest achievable detection at a nonnegative individual cutoff satisfying the default CAP control count, for the otherwise identical no-context rule. This exhausts cutoff settings for this fixed rule and finite sample, not alternative baselines, preprocessing or persistence settings. It remains a test-set oracle comparison, not deployable calibration.

| Condition (d=0.25) | Window | CAP control / 1,440 | NC control / 1,440 | CAP detected / 960 | NC detected / 960 | CAP minus NC (points) |
|---|---|---:|---:|---:|---:|---:|
| q=0, multiplier=none | to_end | 559 | 540 | 679 | 700 | -2.19 |
| q=0, multiplier=none | six_week | 376 | 375 | 608 | 633 | -2.60 |
| q=2, multiplier=0.5 | to_end | 533 | 518 | 668 | 666 | +0.21 |
| q=2, multiplier=0.5 | six_week | 363 | 363 | 596 | 592 | +0.42 |
| q=4, multiplier=0.25 | to_end | 445 | 445 | 580 | 527 | +5.52 |
| q=4, multiplier=0.25 | six_week | 292 | 292 | 513 | 430 | +8.65 |

### Interpretation

- No lull: a stricter no-context rule detects more injected events while using fewer control flags than default CAP in the original seed.
- Original two-week lull: default CAP detects only two more positive events than the exact budget-feasible no-context setting, but uses 15 more control flags. This does not demonstrate an advantage at an exactly equal control count; the no-context attainable count jumps because of tied scores. The interpolated comparison favors no-context.
- Deep four-week lull, d=0.25: the exact control count is matched in the original seed. CAP detects 580 versus 527 positive events at 445 control flags in the primary window; within six weeks, it detects 513 versus 430 at 292 control flags. This is an observed conditional advantage over tightening the individual cutoff for the declared fixed no-context rule. It does not establish general superiority over raw history or other methods.

- Deep four-week lull, to_end: CAP has higher detection than the exact budget-feasible no-context rule in 11/11 existing overlapping seeds; difference ranges from +1.15 to +8.12 points. These are within-pool sampling checks, not independent replications; budgets are each seed's default CAP control rate.
- Deep four-week lull, six_week: CAP has higher detection than the exact budget-feasible no-context rule in 11/11 existing overlapping seeds; difference ranges from +3.33 to +10.10 points. These are within-pool sampling checks, not independent replications; budgets are each seed's default CAP control rate.

### Revised bounded finding

The new exact-threshold comparison supplies evidence beyond the fact that a restrictive gate removes flags. In the tested deep four-week perturbation, the context rule attains a detection/control combination that tightening the individual cutoff of its otherwise identical no-context rule does not attain. Without a lull, the simpler rule performs better at the corresponding budget. This supports a conditional trade-off finding within these post hoc OULAD analyses. It does not resolve the closest-literature novelty question, establish practical usefulness or predict external performance.

All coarse-grid outcomes are retained. The secondary audit must be reported as such rather than silently replacing the original analysis. The manuscript should avoid the blanket claim that context never improves the ordinary trade-off, and also avoid a blanket superiority claim.

Exact-audit reproduction: run `code/exact_frontier_audit.py` and `code/check_exact_canonical.py` with the same package, database and registration arguments as the main analysis; then run `code/report_exact.py`. The amendment records that the coarse results had been seen.

Exact audit checks:
```json
{
  "status": "completed",
  "event_predicates_verified": 1478400,
  "comparisons": 616,
  "coarse_outcomes_inspected_before_amendment": true,
  "original_seed_selected_threshold_canonical_cells": 2688000,
  "selected_threshold_canonical_mismatches": 0
}
```
