"""Rebuild and verify the supplied legacy SQLite ingestion, without running detectors."""
import argparse
import csv
import hashlib
import json
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from engagetrace_db import EngageTraceDB


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def rebuild(input_dir, destination, existing=None):
    started = time.monotonic()
    names = ['courses.csv', 'studentRegistration.csv', 'studentVle.csv']
    for name in names:
        if not (input_dir / name).is_file():
            raise ValueError(f'Missing {name}')
    if destination.exists():
        raise ValueError(f'Refusing to overwrite existing database: {destination}')
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = existing or destination.with_suffix('.building.sqlite3')
    if not existing and temporary.exists():
        raise ValueError(f'Existing incomplete build requires inspection: {temporary}')
    metadata = {name: {'sha256': sha256(input_dir / name), 'bytes': (input_dir / name).stat().st_size} for name in names}
    if not existing:
        print('Source checksums recorded. Starting original SQLite ingestion.', flush=True)
        db = EngageTraceDB(str(temporary))
        try:
            db.init_schema()
            db.ingest_oulad(vle_csv=str(input_dir/'studentVle.csv'), registration_csv=str(input_dir/'studentRegistration.csv'), courses_csv=str(input_dir/'courses.csv'))
        finally:
            db.close()
    elif not existing.is_file():
        raise ValueError(f'Cannot verify missing database: {existing}')
    print('Ingestion complete. Checking source totals and database integrity.', flush=True)
    source = {}
    for name in names[:2]:
        with (input_dir/name).open(newline='', encoding='utf-8-sig') as f:
            source[name] = sum(1 for _ in csv.DictReader(f))
    activity_rows = excluded_rows = excluded_clicks = 0
    totals = {}
    observed = set()
    with (input_dir/'studentVle.csv').open(newline='', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            activity_rows += 1
            day, clicks = int(row['date']), int(row['sum_click'])
            if day < 0:
                excluded_rows += 1
                excluded_clicks += clicks
                continue
            course = row['code_module'] + '_' + row['code_presentation']
            totals[course] = totals.get(course, 0) + clicks
            observed.add((row['id_student'], course, day // 7 + 1))
    with sqlite3.connect(temporary) as con:
        integrity = con.execute('PRAGMA integrity_check').fetchall()
        foreign_keys = con.execute('PRAGMA foreign_key_check').fetchall()
        assert integrity == [('ok',)], integrity
        assert not foreign_keys, foreign_keys[:5]
        counts = {table: con.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0] for table in ['courses','students','weekly_activity','detection_runs','detection_flags']}
        actual = dict(con.execute('SELECT course_id, SUM(clicks) FROM weekly_activity GROUP BY course_id'))
        print('Database counts:', counts, 'source click total:', sum(totals.values()), 'stored:', sum(actual.values()), flush=True)
        assert actual == totals, 'Per-course source totals do not match'
        assert counts['courses'] == source['courses.csv']
        assert counts['students'] == source['studentRegistration.csv']
        assert counts['weekly_activity'] == len(observed)
        assert con.execute('SELECT COUNT(*) FROM weekly_activity WHERE clicks < 0 OR week < 1').fetchone()[0] == 0
        unique_students = con.execute('SELECT COUNT(DISTINCT student_id) FROM students').fetchone()[0]
        course_counts = [dict(zip(['course_id','students','weekly_rows'], row)) for row in con.execute('SELECT c.course_id, (SELECT COUNT(*) FROM students s WHERE s.course_id=c.course_id), (SELECT COUNT(*) FROM weekly_activity w WHERE w.course_id=c.course_id) FROM courses c ORDER BY c.course_id')]
    # Verify that the source bytes stayed unchanged during the build.
    for name in names:
        assert metadata[name]['sha256'] == sha256(input_dir/name), f'Source changed: {name}'
    temporary.rename(destination)
    manifest = {
        'built_at_utc': datetime.now(timezone.utc).isoformat(),
        'builder': 'Supplied engagetrace_db.py ingest_oulad, unchanged',
        'database': destination.name, 'database_bytes': destination.stat().st_size,
        'database_sha256': sha256(destination), 'inputs': metadata,
        'source_rows': {**source, 'studentVle.csv': activity_rows},
        'table_counts': counts, 'unique_student_pseudonyms': unique_students,
        'pre_course_rows_excluded': excluded_rows, 'pre_course_clicks_excluded': excluded_clicks,
        'retained_click_total': sum(totals.values()), 'per_course_click_totals': totals,
        'per_course_counts': course_counts, 'integrity_check': 'ok', 'foreign_key_violations': 0,
        'distinct_source_week_keys_match': True, 'per_course_click_totals_match': True,
        'elapsed_seconds': round(time.monotonic()-started, 2),
        'limitations': [
            'Legacy weeks are one-based: floor(date/7)+1. Requirements specify zero-based weeks; migration remains pending.',
            'Legacy import does not enforce enrollment eligibility or coverage-based zero/missing semantics.',
            'Legacy importer adds clicks on conflict. This runner requires a new destination and must not append to an existing database.',
            'No detector runs were executed. Detection tables are present but empty; experimental results were not recreated.',
            'No final outcomes or demographics imported. final_result is null because it is absent from studentRegistration.csv.',
            'This database has the supplied legacy schema, not the US-01 versioned staging schema. They remain separate artifacts.',
        ],
    }
    destination.with_suffix('.manifest.json').write_text(json.dumps(manifest, indent=2))
    print(json.dumps({k:manifest[k] for k in ['database_bytes','table_counts','retained_click_total','integrity_check','elapsed_seconds']}, indent=2), flush=True)
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, required=True)
    parser.add_argument('--database', type=Path, default=Path('engagetrace.db'))
    parser.add_argument('--verify-existing', type=Path, help='Validate and rename an already built database instead of importing again')
    args = parser.parse_args()
    rebuild(args.input_dir, args.database, args.verify_existing)
