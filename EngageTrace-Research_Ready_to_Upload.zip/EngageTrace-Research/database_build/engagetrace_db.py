"""
EngageTrace database layer.

Builds and queries a SQLite database of weekly LMS activity, and runs the
CAP (Contextual Activity Persistence) detector plus three baselines against
it, storing results back to the database.

Usage (from real OULAD CSVs):

    from engagetrace_db import EngageTraceDB

    db = EngageTraceDB("engagetrace.db")
    db.init_schema()
    db.ingest_oulad(
        vle_csv="studentVle.csv",
        registration_csv="studentRegistration.csv",
        courses_csv="courses.csv",
    )
    run_id = db.run_detection(
        course_id="AAA_2013J",
        k=3, tau_ind=0.5, tau_ctx=1.5, p=2, fixed_threshold=30,
    )
    df = db.get_flags(run_id)
"""

import sqlite3
import statistics
from pathlib import Path

SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def _median(values):
    values = list(values)
    if not values:
        return 0.0
    return statistics.median(values)


def _mad(values):
    values = list(values)
    m = _median(values)
    return _median([abs(v - m) for v in values])


class EngageTraceDB:
    def __init__(self, path="engagetrace.db"):
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.execute("PRAGMA foreign_keys = ON")

    def init_schema(self):
        with open(SCHEMA_PATH) as f:
            self.conn.executescript(f.read())
        self.conn.commit()

    # ---------------- ingestion ----------------

    def ingest_oulad(self, vle_csv, registration_csv, courses_csv, week_days=7):
        """
        Ingest raw OULAD CSVs into the weekly_activity table.

        vle_csv: path to studentVle.csv (columns: code_module, code_presentation,
                 id_student, date, sum_click, ...)
        registration_csv: path to studentRegistration.csv (columns: code_module,
                 code_presentation, id_student, date_registration,
                 date_unregistration, final_result)
        courses_csv: path to courses.csv (columns: code_module, code_presentation,
                 module_presentation_length)
        """
        import csv

        cur = self.conn.cursor()

        with open(courses_csv, newline="") as f:
            for row in csv.DictReader(f):
                course_id = f"{row['code_module']}_{row['code_presentation']}"
                cur.execute(
                    "INSERT OR IGNORE INTO courses (course_id, module, presentation, length_days) "
                    "VALUES (?, ?, ?, ?)",
                    (course_id, row["code_module"], row["code_presentation"],
                     int(row.get("module_presentation_length") or 0)),
                )

        with open(registration_csv, newline="") as f:
            for row in csv.DictReader(f):
                course_id = f"{row['code_module']}_{row['code_presentation']}"
                cur.execute(
                    "INSERT OR IGNORE INTO students (student_id, course_id, final_result) "
                    "VALUES (?, ?, ?)",
                    (row["id_student"], course_id, row.get("final_result")),
                )

        weekly = {}  # (student_id, course_id, week) -> clicks
        with open(vle_csv, newline="") as f:
            for row in csv.DictReader(f):
                course_id = f"{row['code_module']}_{row['code_presentation']}"
                date = int(row["date"])
                week = (date // week_days) + 1
                if week < 1:
                    continue
                key = (row["id_student"], course_id, week)
                weekly[key] = weekly.get(key, 0) + int(row["sum_click"])

        cur.executemany(
            "INSERT INTO weekly_activity (student_id, course_id, week, clicks) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(student_id, course_id, week) DO UPDATE SET clicks = clicks + excluded.clicks",
            [(sid, cid, wk, clicks) for (sid, cid, wk), clicks in weekly.items()],
        )
        self.conn.commit()

    def ingest_dataframe(self, df, course_id, student_col="student_id", week_col="week", clicks_col="clicks"):
        """Ingest already-aggregated weekly activity from a pandas DataFrame."""
        cur = self.conn.cursor()
        cur.execute("INSERT OR IGNORE INTO courses (course_id, module, presentation) VALUES (?, ?, ?)",
                    (course_id, course_id, ""))
        students = df[student_col].unique().tolist()
        cur.executemany(
            "INSERT OR IGNORE INTO students (student_id, course_id) VALUES (?, ?)",
            [(s, course_id) for s in students],
        )
        cur.executemany(
            "INSERT OR REPLACE INTO weekly_activity (student_id, course_id, week, clicks) VALUES (?, ?, ?, ?)",
            [(row[student_col], course_id, int(row[week_col]), int(row[clicks_col])) for _, row in df.iterrows()],
        )
        self.conn.commit()

    # ---------------- retrieval ----------------

    def get_course_matrix(self, course_id):
        """Return {student_id: [clicks_week1, clicks_week2, ...]} for a course, zero-filled."""
        cur = self.conn.cursor()
        cur.execute("SELECT MAX(week) FROM weekly_activity WHERE course_id = ?", (course_id,))
        max_week = cur.fetchone()[0] or 0

        cur.execute("SELECT student_id FROM students WHERE course_id = ?", (course_id,))
        student_ids = [r[0] for r in cur.fetchall()]

        matrix = {sid: [0] * max_week for sid in student_ids}
        cur.execute("SELECT student_id, week, clicks FROM weekly_activity WHERE course_id = ?", (course_id,))
        for sid, week, clicks in cur.fetchall():
            if sid in matrix and 1 <= week <= max_week:
                matrix[sid][week - 1] = clicks
        return matrix

    # ---------------- detection ----------------

    def run_detection(self, course_id, k=3, tau_ind=0.5, tau_ctx=1.5, p=2,
                       fixed_threshold=30, notes=None):
        matrix = self.get_course_matrix(course_id)
        if not matrix:
            raise ValueError(f"No activity found for course {course_id}")

        student_ids = list(matrix.keys())
        weeks = len(next(iter(matrix.values())))

        deltas = {sid: [None] * weeks for sid in student_ids}
        for sid in student_ids:
            vals = matrix[sid]
            for i in range(weeks):
                if i + 1 <= k:
                    continue
                window = vals[i - k:i]
                base = _median(window)
                deltas[sid][i] = (base - vals[i]) / (base + 1e-6)

        z_scores = {sid: [None] * weeks for sid in student_ids}
        for i in range(weeks):
            week_deltas = {sid: deltas[sid][i] for sid in student_ids if deltas[sid][i] is not None}
            for sid in week_deltas:
                others = [v for s, v in week_deltas.items() if s != sid]
                if not others:
                    continue
                med = _median(others)
                madv = _mad(others)
                z_scores[sid][i] = (week_deltas[sid] - med) / (madv + 1e-6)

        flags = {sid: {"fixed": [False] * weeks, "individual": [False] * weeks,
                        "cusum": [False] * weeks, "cap": [False] * weeks}
                 for sid in student_ids}

        for sid in student_ids:
            vals = matrix[sid]
            fixed_run = ind_run = cap_run = 0
            mu0 = _median(vals[:min(k, weeks)])
            slack = 0.25 * mu0
            H = 2 * mu0
            S = 0.0
            for i in range(weeks):
                fixed_run = fixed_run + 1 if vals[i] < fixed_threshold else 0
                flags[sid]["fixed"][i] = fixed_run >= p

                d = deltas[sid][i]
                ind_run = ind_run + 1 if (d is not None and d >= tau_ind) else 0
                flags[sid]["individual"][i] = ind_run >= p

                S = max(0.0, S + (mu0 - vals[i]) - slack)
                flags[sid]["cusum"][i] = bool(S > H and mu0 > 0)

                z = z_scores[sid][i]
                cond = d is not None and z is not None and d >= tau_ind and z >= tau_ctx
                cap_run = cap_run + 1 if cond else 0
                flags[sid]["cap"][i] = cap_run >= p

        cur = self.conn.cursor()
        cur.execute(
            "INSERT INTO detection_runs (course_id, baseline_window_k, tau_individual, "
            "tau_context, persistence_p, fixed_threshold, notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (course_id, k, tau_ind, tau_ctx, p, fixed_threshold, notes),
        )
        run_id = cur.lastrowid

        rows = []
        for sid in student_ids:
            for i in range(weeks):
                for method in ("fixed", "individual", "cusum", "cap"):
                    rows.append((
                        run_id, sid, i + 1, method, int(flags[sid][method][i]),
                        deltas[sid][i], z_scores[sid][i],
                    ))
        cur.executemany(
            "INSERT INTO detection_flags (run_id, student_id, week, method, flagged, "
            "delta_individual, z_context) VALUES (?, ?, ?, ?, ?, ?, ?)",
            rows,
        )
        self.conn.commit()
        return run_id

    def get_flags(self, run_id):
        """Return list of dict rows for a detection run (no pandas dependency)."""
        cur = self.conn.cursor()
        cur.execute(
            "SELECT student_id, week, method, flagged, delta_individual, z_context "
            "FROM detection_flags WHERE run_id = ? ORDER BY student_id, week, method",
            (run_id,),
        )
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]

    def summarize_run(self, run_id):
        """Aggregate counts per method: total flags, useful for the false-alert comparison."""
        cur = self.conn.cursor()
        cur.execute(
            "SELECT method, SUM(flagged) as total_flags "
            "FROM detection_flags WHERE run_id = ? GROUP BY method",
            (run_id,),
        )
        return {row[0]: row[1] for row in cur.fetchall()}

    def export_course_json(self, course_id, path):
        """
        Export one course's weekly activity matrix to JSON, in the shape the
        EngageTrace dashboard's "Load course data" import expects:

            {
              "courseId": "AAA_2013J",
              "weeks": 20,
              "students": [
                {"id": "1000", "finalResult": "Pass", "values": [12, 9, ...]},
                ...
              ]
            }
        """
        import json

        matrix = self.get_course_matrix(course_id)
        if not matrix:
            raise ValueError(f"No activity found for course {course_id}")
        weeks = len(next(iter(matrix.values())))

        cur = self.conn.cursor()
        cur.execute(
            "SELECT student_id, final_result FROM students WHERE course_id = ?",
            (course_id,),
        )
        results = {sid: fr for sid, fr in cur.fetchall()}

        payload = {
            "courseId": course_id,
            "weeks": weeks,
            "students": [
                {"id": sid, "finalResult": results.get(sid), "values": matrix[sid]}
                for sid in matrix
            ],
        }
        with open(path, "w") as f:
            json.dump(payload, f, indent=2)
        return path

    def close(self):
        self.conn.close()
