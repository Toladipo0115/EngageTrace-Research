# EngageTrace extension package (separate from the frozen original)

Nothing here modifies the original frozen protocol, code or results. `vendor/` holds unchanged copies with hashes in `vendor/SHA256SUMS.txt`.

## Needs (not included)
- `engagetrace.db` (table `weekly_activity`: course_id, student_id, week, clicks) and OULAD `studentRegistration.csv`. Do not upload either, or anything in `private_do_not_publish/`, to public GitHub.

## Commands (run from `code/`)
```
pip install -r requirements.txt
export ET_DB=/path/to/engagetrace.db
export ET_REG=/path/to/studentRegistration.csv
python3 verify_original.py                 # reproduces the 192 original summary values
python3 test_equivalence.py                # vectorised vs canonical detectors, zero mismatches
python3 run_grid.py --seed 20261015        # experiment 1 (archived assignments checked)
for s in 20261101 20261102 20261103 20261104 20261105 20261106 20261107 20261108 20261109 20261110; do python3 run_grid.py --seed $s; done
python3 summarize_grid.py                  # exp1 and exp3 summaries
python3 calibrate.py                       # experiment 2
python3 withdrawal.py                      # experiment 4
python3 make_figures.py
```
Each script checks the protocol hash (`protocol/protocol.sha256`) first. Total run time on one core is under one minute.

## Layout
- `protocol/` dated frozen protocol (JSON and Markdown) and hash.
- `config`: all parameters are in `protocol/protocol.json`.
- `results/` machine-readable outputs (CSV, JSON, gz CSV per seed).
- `figures/` four PNG figures. `report/` report. `manuscript_proposed/` separate manuscript update.
- `private_do_not_publish/` sampled student assignments (student IDs). Local only.
