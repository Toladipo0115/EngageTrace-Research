import sys, importlib.util
from core import *
from frozen import load_frozen
G = '../../gh/'
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
ce = load(G + 'Codes and Database/controlled_eval.py', 'ce')                       # original ChatGPT controlled_eval.py
rv = load(G + 'EngageTrace_Experiment_Verification_Package/output/icicip-paper/code/run_validation.py', 'rv')  # event-window v2
cfgv = json.load(open(G + 'EngageTrace_Experiment_Verification_Package/output/icicip-paper/code/protocol.json'))
cfg = RevisedConfig(k=3, lag=3, tau_ind_raw=0.5, tau_ind_log=0.2, tau_ctx_pct=0.6, p=3, fixed_threshold=6.0)
sets = [S for S in make_sets(load_frozen(False), [2], seeds=[20261015])]
paper = {'fixed': (.706, .482), 'individual': (.729, .383), 'cusum': (.879, .742), 'cap': (.696, .370), 'cap_no_context': (.810, .549), 'cap_no_persistence': (.932, .861), 'cap_no_individual': (.797, .498)}
def rates(getflags):
    tot = defaultdict(lambda: [0, 0, 0, 0])
    for S in sets:
        mat = {i: list(map(int, S['M'][i])) for i in range(S['M'].shape[0])}
        fl = getflags(mat)
        for m, arr in fl.items():
            a, pre, st = score(S, arr, 'to_end'); pos = S['pos']
            tot[m][0] += int(a[pos].sum()); tot[m][1] += int(pos.sum()); tot[m][2] += int(a[~pos].sum()); tot[m][3] += int((~pos).sum())
    return {m: (v[0] / v[1], v[2] / v[3]) for m, v in tot.items()}
def to_arr(d, names, n):
    return {m: np.array([d[i][m] for i in range(n)]) for m in names}
names = list(paper)
A = rates(lambda mat: to_arr(detect_revised(mat, cfg), names, len(mat)))                         # (A) validation package detectors module
B = rates(lambda mat: to_arr(ce.compute_flags(mat, 3, 0.5, 0.6, 3, 6.0, tau_ind_log=0.2), names, len(mat)))   # (B) original controlled_eval.py
def runC(mat, upper):
    M = [mat[i] for i in range(len(mat))]; out = rv.detect(M, cfgv, upper_ties=upper)
    mp = {'fixed': 'fixed', 'individual': 'raw_individual', 'cusum': 'cusum', 'cap': 'cap', 'cap_no_context': 'log_individual', 'cap_no_persistence': 'no_persistence', 'cap_no_individual': 'no_individual'}
    return {k: np.array(out[v]) for k, v in mp.items()}
Cm = rates(lambda mat: runC(mat, False)); Cu = rates(lambda mat: runC(mat, True))
print(f"{'method':20s} {'paper(det,ctrl)':16s} {'A validation pkg':16s} {'B controlled_eval':17s} {'C midrank':16s} {'C upper':16s}")
for m in names:
    f = lambda t: f"{t[0]:.3f},{t[1]:.3f}"
    print(f"{m:20s} {f(paper[m]):16s} {f(A[m]):16s} {f(B[m]):17s} {f(Cm[m]):16s} {f(Cu[m]):16s}")
