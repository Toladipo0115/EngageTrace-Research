from core import *
FROZEN = ['BBB_2013B','BBB_2014B','CCC_2014B','DDD_2013B','DDD_2014B','DDD_2014J','FFF_2013B','FFF_2014B']
PREV = set(DEV) | set(TEST)
def load_frozen(verbose=True):
    regs = list(csv.DictReader(open(REG)))
    exposed = {r['id_student'] for r in regs if r['code_module'] + '_' + r['code_presentation'] in PREV}
    counts = defaultdict(int); elig = defaultdict(list)
    for r in regs:
        c = r['code_module'] + '_' + r['code_presentation']
        if c not in FROZEN: continue
        counts['candidate'] += 1
        if r['id_student'] in exposed: counts['exposed'] += 1; continue
        if r['date_registration'] in ('', '?') or int(r['date_registration']) > 0: counts['late'] += 1; continue
        if r['date_unregistration'] not in ('', '?') and int(r['date_unregistration']) < 140: counts['early_withdraw'] += 1; continue
        elig[c].append(r['id_student'])
    pools = {}
    with sqlite3.connect(f'file:{Path(DB).resolve()}?mode=ro', uri=True) as con:
        for c, ids in sorted(elig.items()):
            m = {s: [0] * T for s in ids}
            for sid, w, x in con.execute('SELECT student_id,week,clicks FROM weekly_activity WHERE course_id=? AND week BETWEEN 1 AND 20', (c,)):
                if sid in m: m[sid][w - 1] = x
            for s in list(m):
                if not sum(m[s]): counts['zero'] += 1; del m[s]
            pools[c] = m
    # duplicates across courses: keep lexicographically first eligible presentation
    seen = {}
    for c in sorted(pools):
        for s in list(pools[c]):
            if s in seen: counts['dup'] += 1; del pools[c][s]
            else: seen[s] = c
    counts['distinct'] = sum(len(v) for v in pools.values())
    if verbose: print(dict(counts))
    return pools
if __name__ == '__main__':
    load_frozen()
