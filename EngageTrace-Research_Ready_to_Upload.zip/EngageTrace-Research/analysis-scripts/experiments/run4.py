from core import *
from frozen import load_frozen
import itertools
def signflip(d):
    d = np.array(d); n = len(d); obs = abs(d.mean()); cnt = 0
    for s in itertools.product([1, -1], repeat=n):
        if abs((d * np.array(s)).mean()) >= obs - 1e-12: cnt += 1
    return cnt / 2 ** n
CTRL = {'no_change', 'temporary', 'quiet_only'}
out = {}
for sp, sets in [('frozen', make_sets(load_frozen(False), [0, 2, 4], seeds=[20261015])), ('transfer', make_sets(load_pool(TEST, dev_students()), [0, 2, 4]))]:
    byc = defaultdict(lambda: defaultdict(dict))
    for S in sets:
        F = feats(S['M']); ctrl = np.isin(np.array(S['scen']), list(CTRL))
        for nm, fn in [('CAP', f_cap), ('Raw history', f_raw), ('Log decline only', f_noctx), ('Fixed', f_fixed), ('CUSUM', f_cusum)]:
            a = fn(F)[:, 6:].any(1)[ctrl]
            byc[S['course']][(nm, S['q'])].setdefault(S['seed'], a.mean())
    courses = sorted(byc)
    delta = {}
    for nm in ['CAP', 'Raw history', 'Log decline only', 'Fixed', 'CUSUM']:
        for q in [2, 4]:
            delta[(nm, q)] = [float(np.mean(list(byc[c][(nm, q)].values())) - np.mean(list(byc[c][(nm, 0)].values()))) for c in courses]
    res = {'courses': courses}
    for (nm, q), d in delta.items():
        res[f'{nm}|q{q}'] = dict(per_course=d, mean=float(np.mean(d)), up=int(sum(x > 0 for x in d)), down=int(sum(x < 0 for x in d)))
    for base in ['Raw history', 'Log decline only', 'Fixed', 'CUSUM']:
        for q in [2, 4]:
            dd = [a - b for a, b in zip(delta[('CAP', q)], delta[(base, q)])]
            res[f'CAP-minus-{base}|q{q}'] = dict(diffs=dd, mean=float(np.mean(dd)), cap_lower=int(sum(x < 0 for x in dd)), p_signflip=signflip(dd))
    out[sp] = res
    for q in [2, 4]:
        print(sp, 'q', q, {nm: round(res[f'{nm}|q{q}']['mean'], 3) for nm in ['CAP', 'Raw history', 'Log decline only', 'Fixed', 'CUSUM']},
              'CAP-raw', round(res[f'CAP-minus-Raw history|q{q}']['mean'], 3), res[f'CAP-minus-Raw history|q{q}']['cap_lower'], round(res[f'CAP-minus-Raw history|q{q}']['p_signflip'], 4),
              'CAP-log', round(res[f'CAP-minus-Log decline only|q{q}']['mean'], 3), res[f'CAP-minus-Log decline only|q{q}']['cap_lower'], round(res[f'CAP-minus-Log decline only|q{q}']['p_signflip'], 4))
json.dump(out, open('run4.json', 'w'), default=float)
