from core import *
from frozen import load_frozen
sets = make_sets(load_frozen(False), [2, 4], seeds=[20261015])
def meths(F, mat):
    pk = detect_park_prefix(mat)
    return {'Fixed': f_fixed(F), 'Raw history': f_raw(F), 'CUSUM': f_cusum(F), 'Park Poisson': np.array([pk[i] for i in range(len(mat))]),
            'No context': f_noctx(F), 'No persistence': f_cap(F, 0.2, 0.6, 1), 'No individual': persist(ge(F['rank'], 0.6), 3), 'CAP': f_cap(F)}
out = {}
for q in [2, 4]:
    acc = defaultdict(lambda: defaultdict(list))
    for S in sets:
        if S['q'] != q: continue
        F = feats(S['M']); mat = {i: list(map(int, S['M'][i])) for i in range(S['M'].shape[0])}
        for m, fl in meths(F, mat).items():
            for w in ['to_end', 'w6']:
                a, pre, st = score(S, fl, w); pos = S['pos']
                acc[(m, w)]['det'].append(a[pos]); acc[(m, w)]['strict_det'].append(st[pos]); acc[(m, w)]['pre_pos'].append(pre[pos])
                acc[(m, w)]['fa'].append(a[~pos]); acc[(m, w)]['strict_fa'].append(st[~pos]); acc[(m, w)]['pre_neg'].append(pre[~pos])
            anyt = fl.any(1); pos = S['pos']
            acc[(m, 'any')]['det'].append(anyt[pos]); acc[(m, 'any')]['fa'].append(anyt[~pos])
    out[q] = {f'{m}|{w}': {k: (float(np.concatenate(v).mean()), int(np.concatenate(v).sum()), len(np.concatenate(v))) for k, v in d.items()} for (m, w), d in acc.items()}
json.dump(out, open('newnums.json', 'w'))
for m in ['Fixed', 'Raw history', 'CUSUM', 'Park Poisson', 'No context', 'No persistence', 'No individual', 'CAP']:
    e = out[2][f'{m}|to_end']; a = out[2][f'{m}|any']; w = out[2][f'{m}|w6']
    print(f"{m:15s} any {a['det'][0]:.3f}/{a['fa'][0]:.3f} | post {e['det'][0]:.3f}/{e['fa'][0]:.3f} strict {e['strict_det'][0]:.3f} pre+ {e['pre_pos'][0]:.3f} pre- {e['pre_neg'][0]:.3f} | w6 {w['det'][0]:.3f}/{w['fa'][0]:.3f} strict {w['strict_det'][0]:.3f}")
