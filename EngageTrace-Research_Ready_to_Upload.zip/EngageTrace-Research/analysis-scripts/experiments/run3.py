from core import *
from frozen import load_frozen
import itertools
purge = dev_students()
fro = make_sets(load_frozen(False), [0, 2, 4], seeds=[20261015])
tra = make_sets(load_pool(TEST, purge), [2, 4])
dev = make_sets(load_pool(DEV), [2])
res = {}
# E3 filter pass fractions (frozen)
fr = {}
for q in [0, 2, 4]:
    acc = defaultdict(list)
    for S in fro:
        if S['q'] != q: continue
        F = feats(S['M'])
        for t in range(6, 20):
            acc['rank>=0.6'].append((t + 1, float(np.mean(F['rank'][:, t] >= 0.6))))
            acc['decline>=0.2'].append((t + 1, float(np.mean(F['ld'][:, t] >= 0.2))))
            acc['excess>=0.3'].append((t + 1, float(np.mean((F['ld'][:, t] - F['med'][:, t]) >= 0.3))))
    fr[q] = {k: [float(np.mean([v for w, v in lst if w == wk])) for wk in range(7, 21)] for k, lst in acc.items()}
res['filter'] = fr
# E4 sensitivity on DEV
def sens(sets, name, variants):
    out = []
    for lab, fn, kk, ll in variants:
        for window in ['to_end', 'w6']:
            ms = []
            for S in sets:
                if S['q'] != 2: continue
                F = feats(S['M'], kk, ll); ms.append((S['course'], metrics(S, fn(F), window)))
            m, _ = course_means(ms)
            out.append(dict(param=name, value=lab, window=window, **m))
    return out
sv = []
sv += sens(dev, 'tau_ind', [(x, (lambda F, x=x: f_cap(F, x, .6)), 3, 3) for x in [0.1, 0.15, 0.2, 0.3, 0.4, 0.5]])
sv += sens(dev, 'tau_ctx', [(x, (lambda F, x=x: f_cap(F, .2, x)), 3, 3) for x in [0.4, 0.5, 0.6, 0.7, 0.8, 0.9]])
sv += sens(dev, 'p', [(x, (lambda F, x=x: f_cap(F, .2, .6, x)), 3, 3) for x in [1, 2, 3, 4, 5]])
sv += sens(dev, 'k', [(x, (lambda F: f_cap(F)), x, 3) for x in [2, 3, 4, 5]])
sv += sens(dev, 'lag', [(x, (lambda F: f_cap(F)), 3, x) for x in [0, 1, 2, 3, 4, 5]])
res['sensitivity_dev'] = sv
# E5 per presentation differences + exact sign flip
def signflip(d):
    d = np.array(d); n = len(d); obs = abs(d.mean()); cnt = 0
    for signs in itertools.product([1, -1], repeat=n):
        if abs((d * np.array(signs)).mean()) >= obs - 1e-12: cnt += 1
    return cnt / 2 ** n
pc = {}
for sp, sets in [('frozen', fro), ('transfer', tra)]:
    for q in [2, 4]:
        for window in ['to_end', 'w6']:
            per = {}
            for nm, fn in [('CAP', f_cap), ('Fixed', f_fixed), ('Raw history', f_raw), ('Log decline only', f_noctx), ('CUSUM', f_cusum)]:
                _, cm = evaluate(sets, fn, window, q); per[nm] = cm
            courses = sorted(per['CAP'])
            entry = dict(courses=courses, per=per)
            for base in ['Fixed', 'Raw history', 'Log decline only', 'CUSUM']:
                for met in ['det', 'fa', 'strict_det', 'strict_fa']:
                    d = [per['CAP'][c][met] - per[base][c][met] for c in courses]
                    entry[f'{base}:{met}'] = dict(diffs=d, mean=float(np.mean(d)), better=int(sum(x > 0 for x in d)), worse=int(sum(x < 0 for x in d)), p_signflip=signflip(d))
            pc[f'{sp}|q{q}|{window}'] = entry
res['per_presentation'] = pc
# E6 PPV
ppv = []
for q in [2, 4]:
    for window in ['to_end', 'w6']:
        for nm, fn in [('CAP', f_cap), ('Fixed', f_fixed), ('Raw history', f_raw), ('Log decline only', f_noctx), ('CUSUM', f_cusum)]:
            m, _ = evaluate(fro, fn, window, q)
            for pi in [0.01, 0.02, 0.05, 0.10, 0.40]:
                tp = m['det'] * pi; fp = m['fa'] * (1 - pi)
                ppv.append(dict(q=q, window=window, method=nm, prevalence=pi, tpr=m['det'], fpr=m['fa'], ppv=tp / (tp + fp), flagged_per_1000=1000 * (tp + fp)))
res['ppv'] = ppv
json.dump(res, open('run3.json', 'w'), default=float)
print('ok')
