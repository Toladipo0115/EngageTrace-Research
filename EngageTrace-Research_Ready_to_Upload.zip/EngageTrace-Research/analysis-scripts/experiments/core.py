"""Extension experiments for EngageTrace: fast vectorised detectors validated against the repository's detect_revised."""
import csv, json, math, random, sqlite3, sys, statistics
from collections import defaultdict
from pathlib import Path
import numpy as np
import os
sys.path.insert(0, os.environ.get('ENGAGETRACE_VALIDATION_CODE', '../val/code'))
from engagetrace_detectors import RevisedConfig, detect_revised
from park_poisson import detect_park_prefix

DB = os.environ.get('ENGAGETRACE_DB', '../engagetrace.db')
REG = os.environ.get('ENGAGETRACE_REG', '../studentRegistration.csv')
SCEN = ['no_change', 'sustained', 'temporary', 'quiet_only', 'decline_during_quiet']
ONS = dict(zip(SCEN, [12, 12, 15, 7, 7]))
POS = {'sustained', 'decline_during_quiet'}
TEST = ['AAA_2013J', 'AAA_2014J', 'EEE_2013J', 'EEE_2014B', 'EEE_2014J', 'GGG_2013J', 'GGG_2014B', 'GGG_2014J']
DEV = ['CCC_2014J', 'FFF_2014J', 'FFF_2013J', 'BBB_2014J', 'BBB_2013J', 'DDD_2013J']
SEEDS = [101, 202, 303, 404, 505]
T = 20

def load_pool(presentations, purge=None):
    regs = list(csv.DictReader(open(REG)))
    elig = defaultdict(list)
    for r in regs:
        c = r['code_module'] + '_' + r['code_presentation']
        if c not in presentations: continue
        if purge and r['id_student'] in purge: continue
        if r['date_registration'] in ('', '?') or int(r['date_registration']) > 0: continue
        if r['date_unregistration'] not in ('', '?') and int(r['date_unregistration']) < 140: continue
        elig[c].append(r['id_student'])
    data = {}
    with sqlite3.connect(f'file:{Path(DB).resolve()}?mode=ro', uri=True) as con:
        for c, ids in sorted(elig.items()):
            m = {s: [0] * T for s in ids}
            for sid, w, x in con.execute('SELECT student_id,week,clicks FROM weekly_activity WHERE course_id=? AND week BETWEEN 1 AND 20', (c,)):
                if sid in m: m[sid][w - 1] = x
            for s in list(m):
                if not sum(m[s]): del m[s]
            data[c] = m
    return data

def dev_students():
    return {r['id_student'] for r in csv.DictReader(open(REG)) if r['code_module'] + '_' + r['code_presentation'] in DEV}

def make_sets(pool, qs, seeds=SEEDS, n=300):
    """Yield dict(course, seed, q, M (n,T) int array, scen list, onset array 0-based)."""
    out = []
    for course, p in sorted(pool.items()):
        for seed in seeds:
            ids = random.Random(f'{course}:{seed}').sample(sorted(p), n)
            scen = [SEN for SEN in (SCEN[j // (n // 5)] for j in range(n))]
            for q in qs:
                rows = []
                for j, sid in enumerate(ids):
                    v = p[sid][:]
                    for w in range(7, 7 + q): v[w - 1] = round(v[w - 1] * .5)
                    c = scen[j]
                    if c in POS:
                        for w in range(ONS[c], 21): v[w - 1] = round(v[w - 1] * .25)
                    elif c == 'temporary': v[14] = round(v[14] * .25)
                    rows.append(v)
                out.append(dict(course=course, seed=seed, q=q, ids=ids, M=np.array(rows, dtype=float), scen=scen,
                                onset=np.array([ONS[c] - 1 for c in scen]), pos=np.array([c in POS for c in scen])))
    return out

def feats(M, k=3, lag=3):
    n = M.shape[0]; T = M.shape[1]
    L = np.fromiter((math.log1p(v) for v in M.ravel()), dtype=float, count=M.size).reshape(M.shape)
    ld = np.full(M.shape, np.nan); rd = np.full(M.shape, np.nan)
    for t in range(k + lag, T):
        lb = np.median(L[:, t - k - lag:t - lag], axis=1); ld[:, t] = lb - L[:, t]
        rb = np.median(M[:, t - k - lag:t - lag], axis=1); rd[:, t] = (rb - M[:, t]) / (rb + 1e-6)
    rank = np.full(M.shape, np.nan)
    for t in range(k + lag, T):
        col = np.sort(ld[:, t]); rank[:, t] = np.searchsorted(col, ld[:, t], side='right') / n
    med = np.full(M.shape, np.nan)
    for t in range(k + lag, T): med[:, t] = np.median(ld[:, t])
    return dict(ld=ld, rd=rd, rank=rank, med=med, M=M, k=k)

def persist(cond, p):
    run = np.zeros(cond.shape[0]); out = np.zeros(cond.shape, dtype=bool)
    for t in range(cond.shape[1]):
        run = (run + 1) * cond[:, t]; out[:, t] = run >= p
    return out

def ge(a, th):
    with np.errstate(invalid='ignore'): return np.nan_to_num(a, nan=-1e9) >= th

def f_cap(F, ti=0.2, tc=0.6, p=3): return persist(ge(F['ld'], ti) & ge(F['rank'], tc), p)
def f_noctx(F, ti=0.2, p=3): return persist(ge(F['ld'], ti), p)
def f_raw(F, tr=0.5, p=3): return persist(ge(F['rd'], tr), p)
def f_fixed(F, th=6, p=3): return persist(F['M'] < th, p)
def f_excess(F, ti=0.2, delta=0.2, p=3):
    ex = F['ld'] - F['med']
    return persist(ge(F['ld'], ti) & ge(ex, delta), p)
def f_cusum(F, H=2.0):
    M = F['M']; k = F['k']; T = M.shape[1]; mu = np.median(M[:, :k], axis=1); S = np.zeros(M.shape[0]); out = np.zeros(M.shape, dtype=bool)
    for t in range(T):
        S = np.maximum(0, S + (mu - M[:, t]) - .25 * mu); out[:, t] = (S > H * mu) & (mu > 0)
    return out

def score(S, flags, window):
    """Per-student alarm, pre-onset, strict arrays."""
    n = flags.shape[0]; on = S['onset']
    idx = np.arange(T)[None, :]
    hi = np.full(n, T - 1) if window == 'to_end' else np.minimum(on + 5, T - 1)
    inwin = (idx >= on[:, None]) & (idx <= hi[:, None])
    alarm = (flags & inwin).any(1); pre = (flags & (idx < on[:, None])).any(1)
    return alarm, pre, alarm & ~pre

def course_means(sets_metrics):
    """sets_metrics: list of (course, dict) -> equal-weight course mean."""
    by = defaultdict(list)
    for c, d in sets_metrics: by[c].append(d)
    keys = sets_metrics[0][1].keys()
    cm = {c: {k: float(np.mean([d[k] for d in v])) for k in keys} for c, v in by.items()}
    return {k: float(np.mean([cm[c][k] for c in cm])) for k in keys}, cm

def metrics(S, flags, window):
    a, pre, st = score(S, flags, window); pos = S['pos']
    return dict(det=a[pos].mean(), strict_det=st[pos].mean(), pre_pos=pre[pos].mean(),
                fa=a[~pos].mean(), strict_fa=st[~pos].mean(), pre_neg=pre[~pos].mean())

def evaluate(sets, fn, window, q, extra=None):
    res = []
    for S in sets:
        if S['q'] != q: continue
        F = S.setdefault('F', feats(S['M']))
        res.append((S['course'], metrics(S, fn(F), window)))
    return course_means(res)
