from core import *
# 1. validate fast detectors against repository detect_revised on test sets (all 7 methods that overlap)
pool = load_pool(TEST, dev_students())
sets = make_sets(pool, [2, 4])
cfg = RevisedConfig(k=3, lag=3, tau_ind_raw=0.5, tau_ind_log=0.2, tau_ctx_pct=0.6, p=3, fixed_threshold=6.0)
bad = 0; tot = 0
for S in sets[:30]:
    mat = {i: list(map(int, S['M'][i])) for i in range(len(S['ids']))}
    ref = detect_revised(mat, cfg); F = feats(S['M'])
    for name, fl in [('cap', f_cap(F)), ('cap_no_context', f_noctx(F)), ('individual', f_raw(F)), ('fixed', f_fixed(F)), ('cusum', f_cusum(F))]:
        r = np.array([ref[i][name] for i in range(len(S['ids']))])
        tot += r.size; bad += int((r != fl).sum())
print('validated cells', tot, 'mismatches', bad)
