from core import *
from frozen import load_frozen, FROZEN
import time, pickle
exec(open('run1.py').read().split("CURVES = {")[0].split("t0 = time.time()")[0])  # imports only
src = open('run1.py').read()
curves_src = "CURVES = {" + src.split("CURVES = {")[1].split("rows = []")[0]
exec(curves_src)
t0 = time.time()
fro = make_sets(load_frozen(False), [0, 2, 4], seeds=[20261015])
for S in fro: S['F'] = feats(S['M'])
rows = []
for q in [2, 4]:
    for window in ['to_end', 'w6']:
        for fam, items in CURVES.items():
            for name, fn in items:
                m, cm = evaluate(fro, fn, window, q)
                rows.append(dict(split='frozen', q=q, window=window, family=fam, setting=name, **m))
old = json.load(open('curves.json'))
json.dump(old + rows, open('curves_all.json', 'w'))
print('done', round(time.time() - t0))
pickle.dump([{k: v for k, v in S.items() if k != 'F'} for S in fro], open('frozen_sets.pkl', 'wb'))
