# EngageTrace v6 research release

## Start here

- paper/: the current v6 Word manuscript, inspected ten-page PDF, revision notes and structural checks.
- engagetrace-mechanism/: new post hoc A2 matched-control and A3 suppression analysis, exact-cutoff follow-up, source, protocols, complete aggregate outputs, vector figures and installed dependency lock.
- original-frozen-validation/: original frozen generator, canonical detectors, protocol and aggregate results. Private assignments are supplied separately.
- extension-experiments/: original post hoc 28-condition extension, aggregate results, protocols and preserved vendor source.
- analysis-scripts/: historical scripts and JSON outputs behind earlier manuscript results; some original working-folder paths may require adaptation. See its original README. These files are retained as historical artifacts, not certified as a one-command clean rebuild.
- dashboard/: existing checked dashboard source and standalone HTML. No new visual redesign or browser verification was performed in this packaging step. The dashboard does not display the new mechanism experiments automatically and does not connect directly to SQLite. Use Load course data with an exported JSON when appropriate.
- database_build/: original schema, rebuild runner, importer and verification records, without student data.
- docs/: aggregate development-recovery and provenance reports. Exact original cases were recovered; original selection and parameter-selection history remain incomplete.

## Which detector to use

For the paper, use the canonical RevisedConfig / detect_revised implementation under original-frozen-validation/code or the identical vendored research implementation, with the recorded protocol. The original engagetrace_db.py includes the older raw-click/MAD detector. It is retained for database reconstruction and historical behavior; running its legacy run_detection is not a reproduction of paper v6's revised CAP. The new mechanism scripts check against canonical outputs.

## Reproduce the new mechanism analysis

After extracting the private data package separately, run from engagetrace-mechanism/:

    python code/run_mechanism.py --package ../extension-experiments --database /PRIVATE/database/engagetrace.db --registration /PRIVATE/inputs/studentRegistration.csv --assignments /PRIVATE/private_do_not_publish/original_assignments.csv --private-output /PRIVATE/new_diagnostics
    python code/summarize.py
    python code/interpret.py
    python code/exact_frontier_audit.py --package ../extension-experiments --database /PRIVATE/database/engagetrace.db --registration /PRIVATE/inputs/studentRegistration.csv
    python code/check_exact_canonical.py --package ../extension-experiments --database /PRIVATE/database/engagetrace.db --registration /PRIVATE/inputs/studentRegistration.csv
    python code/report_exact.py

Install engagetrace-mechanism/requirements-lock.txt in a separate environment. Exact Python/platform/input hashes are in its manifest. These are documented rerun commands; the separate clean-environment rebuild has NOT yet been completed. Source data and per-student outputs are excluded from this research archive.

## Evidence status

The original frozen evaluation and the later exploratory extensions are distinct. The new mechanism plan preceded its outputs; the exact-cutoff amendment followed inspection of the coarse outcomes. Neither is untouched external confirmation. Retain unfavorable and favorable results. Do not infer false-alarm reduction, intervention benefit or general superiority from lower control flags.

The database remains unchanged; new results are aggregate files, not new rows in detection_runs/detection_flags. Original source files and previously supplied packages are preserved. This bundle was not uploaded to GitHub.

## Repository packaging

The large threshold-sweep CSV is gzip-compressed without changing its contents. summarize.py reads the CSV or its .gz copy. The root SHA256_REPOSITORY.txt records this extracted repository layout; historical source manifests remain provenance records for their original packages.

## Rebuild the excluded database

The database and raw student data are intentionally excluded. Follow [database_build/README.md](database_build/README.md) for the required OULAD CSVs, Python setup, rebuild command, integrity checks, and dashboard export steps. Database reconstruction is separate from reproducing the paper's experiments.
